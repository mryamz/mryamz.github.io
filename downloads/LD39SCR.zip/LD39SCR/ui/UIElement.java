package ui;

import java.awt.Graphics2D;
import java.awt.Polygon;
import java.awt.event.MouseEvent;

public interface UIElement {

	void update();
	
	void draw(Graphics2D g2);
	
	Polygon getBounds();
	
	void mousePressed(MouseEvent e);
	
	void mouseReleased(MouseEvent e);
	
	void mouseMoved(MouseEvent e);
	
}
