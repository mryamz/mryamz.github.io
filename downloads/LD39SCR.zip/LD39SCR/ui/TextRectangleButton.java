package ui;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.Polygon;
import java.awt.Rectangle;
import java.awt.event.MouseEvent;

public class TextRectangleButton extends Pushable {

	protected Polygon bounds;
	private Rectangle rect;

	protected String text;
	protected Font font;

	protected Color bg_color;
	protected Color fnt_color;

	public TextRectangleButton(int x, int y, int w, int h) {
		rect = new Rectangle(x, y, w, h);
		int[] pointsX = {x, x + w, x + w, x};
		int[] pointsY = {y, y, y + h, y + h};
		bounds = new Polygon(pointsX, pointsY, 4);
		bg_color = Color.BLACK;
		fnt_color = Color.WHITE;
		text = "Button";
		font = new Font("System", Font.PLAIN, 16);
	}

	@Override
	public void update() {

	}

	@Override
	public void draw(Graphics2D g2) {
		Font old = g2.getFont();
		g2.setFont(font);
		if (isHovering()) {
			int s = 0;
			g2.setColor(bg_color);
			g2.fillRect(rect.x - s / 2, rect.y - s / 2, rect.width + s, rect.height + s);
			g2.setColor(fnt_color);
			g2.drawString(text, (rect.x - s / 2) + (rect.width + s) / 2 - g2.getFontMetrics().stringWidth(text) / 2, (rect.y - s / 2) + (rect.height + s) / 2 + (int) g2.getFontMetrics().getStringBounds(text, g2).getHeight() / 2);

			g2.setStroke(new BasicStroke(3));

			// left
			g2.setColor(new Color(20, 20, 20));
			g2.drawLine(rect.x, rect.y, rect.x, rect.y + rect.height);

			// top
			g2.setColor(new Color(60, 60, 60));
			g2.drawLine(rect.x, rect.y, rect.x + rect.width, rect.y);

			// right
			g2.setColor(new Color(255, 255, 255));
			g2.drawLine(rect.x + rect.width, rect.y + rect.height, rect.x + rect.width, rect.y);

			// bottom
			g2.setColor(new Color(223, 223, 223));
			g2.drawLine(rect.x, rect.y + rect.height, rect.x + rect.width, rect.y + rect.height);
			g2.setStroke(new BasicStroke(1));

		} else {
			g2.setColor(bg_color);
			g2.fillRect(rect.x, rect.y, rect.width, rect.height);
			g2.setColor(fnt_color);
			g2.drawString(text, rect.x + rect.width / 2 - g2.getFontMetrics().stringWidth(text) / 2, rect.y + rect.height / 2 + (int) (g2.getFontMetrics().getStringBounds(text, g2).getHeight() / 4));
			g2.setColor(bg_color.darker());

			g2.setStroke(new BasicStroke(3));
			// left
			g2.setColor(Color.WHITE);
			g2.drawLine(rect.x, rect.y, rect.x, rect.y + rect.height);

			// top
			g2.setColor(new Color(223, 223, 223));
			g2.drawLine(rect.x, rect.y, rect.x + rect.width, rect.y);

			// right
			g2.setColor(new Color(20, 20, 20));
			g2.drawLine(rect.x + rect.width, rect.y + rect.height, rect.x + rect.width, rect.y);

			// bottom
			g2.setColor(new Color(60, 60, 60));
			g2.drawLine(rect.x, rect.y + rect.height, rect.x + rect.width, rect.y + rect.height);

			g2.setStroke(new BasicStroke(1));
		}
		
		g2.setFont(old);
	}

	@Override
	public void mousePressed(MouseEvent e) {

	}

	@Override
	public Polygon getBounds() {
		return bounds;
	}

	public TextRectangleButton setFnt_color(Color fnt_color) {
		this.fnt_color = fnt_color;
		return this;
	}

	public TextRectangleButton setBg_color(Color bg_color) {
		this.bg_color = bg_color;
		return this;
	}

	public TextRectangleButton setText(String text) {
		this.text = text;
		return this;
	}

	public TextRectangleButton setFont(Font font) {
		this.font = font;
		return this;
	}
}
