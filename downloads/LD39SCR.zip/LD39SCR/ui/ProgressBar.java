package ui;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.Polygon;
import java.awt.Rectangle;

public class ProgressBar extends Pushable {

	private Polygon poly;
	private Rectangle progress;
	private Color primary, secondary;
	private final int MAX_WIDTH;

	private String text = "Unset";
	private int x, y;

	public ProgressBar(int x, int y, int w, int h, Color primary, Color secondary) {
		this.x = x;
		this.y = y;
		this.primary = primary;
		this.secondary = secondary;
		MAX_WIDTH = w;

		progress = new Rectangle(x, y, w, h);
		poly = new Polygon(new int[] { x, x + w, x + w, x }, new int[] { y, y, y + h, y + h }, 4);
	}

	@Override
	public void update() {

	}

	@Override
	public void draw(Graphics2D g2) {
		g2.setColor(primary);
		g2.fillPolygon(poly);
		g2.setColor(secondary);
		g2.fill(progress);

		g2.setColor(Color.WHITE);
		g2.setFont(new Font("Arial", Font.PLAIN, 24));
		g2.drawString(text, x + MAX_WIDTH / 2 - g2.getFontMetrics().stringWidth(text) / 2, y + 35);

	}

	public void setText(String text) {
		this.text = text;
	}

	public void setPercentage(double decimal) {
		progress.width = (int) (MAX_WIDTH * decimal);
	}

	@Override
	public Polygon getBounds() {
		return poly;
	}

}
