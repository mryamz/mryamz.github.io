package ui;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Polygon;
import java.awt.image.BufferedImage;

import main.Main;

public class ImageButton extends Pushable {

	protected Polygon bounds;

	private BufferedImage onHover, idle;
	private int startPointX, startPointY;
	
	public ImageButton(int drawX, int drawY, int[] xPoints, int[] yPoints, BufferedImage onHover, BufferedImage idle) {
		if (xPoints.length != yPoints.length) {
			throw new IllegalArgumentException("The x and y coordinates do not match up.");
		}
		startPointX = drawX;
		startPointY = drawY;
		bounds = new Polygon(xPoints, yPoints, xPoints.length);

		this.onHover = onHover;
		this.idle = idle;
	}

	@Override
	public void update() {

	}

	@Override
	public void draw(Graphics2D g2) {

		if (!isHovering()) {
			g2.drawImage(onHover, startPointX, startPointY, null);
		} else {
			g2.drawImage(idle, startPointX, startPointY, null);
		}

		if (Main.isDebug) {
			g2.setColor(Color.RED);
			g2.drawPolygon(bounds);
		}
	}
	
	public void shiftPolys(int amountX, int amountY) {
		startPointX += amountX;
		startPointY += amountY;
		bounds.translate(amountX, amountY);
	}

	@Override
	public Polygon getBounds() {
		return bounds;
	}
}
