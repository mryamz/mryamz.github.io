package ui;

import java.awt.image.BufferedImage;

import javax.imageio.ImageIO;

public class Images {

	public static BufferedImage MENU_BG;
	public static BufferedImage PLAY_BG;
	public static BufferedImage PLAY_BTN_PUSHED;
	public static BufferedImage PLAY_BTN_IDLE;

	public static BufferedImage END_POWER_LINE_FIXED;
	public static BufferedImage END_POWER_LINE_HURT;
	public static BufferedImage MID_POWER_LINE_FIXED;
	public static BufferedImage MID_POWER_LINE_HURT;
	public static BufferedImage START_POWER_LINE_FIXED;
	public static BufferedImage START_POWER_LINE_HURT;

	public static BufferedImage CLOUD_STATE_1_SHEET;
	public static BufferedImage CLOUD_STATE_2_SHEET;
	public static BufferedImage CLOUD_STATE_3_SHEET;

	public static BufferedImage BOOM_1_SHEET;
	public static BufferedImage WATER_PICKUP;

	public static BufferedImage FIRE_SHEET;
	public static BufferedImage LIGHTNING_SHEET_1;
	
	public static BufferedImage WINDMIL_HURT;
	public static BufferedImage WINDMIL_FIXED;
	
	public static BufferedImage POWER_PLANT_FIXED;
	public static BufferedImage POWER_PLANT_HURT_SHEET;
	
	public static BufferedImage ENERGY_STATION_SHEET;

	static {
		try {
			MENU_BG = ImageIO.read(Class.class.getResourceAsStream("/bgs/menu_bg.png"));
			PLAY_BG = ImageIO.read(Class.class.getResourceAsStream("/bgs/play_bg.png"));
			PLAY_BTN_PUSHED = ImageIO.read(Class.class.getResourceAsStream("/ui/PLAY_PUSHED.png"));
			PLAY_BTN_IDLE = ImageIO.read(Class.class.getResourceAsStream("/ui/PLAY_IDLE.png"));

			END_POWER_LINE_FIXED = ImageIO.read(Class.class.getResourceAsStream("/game_objects/end_power_line_fixed.png"));
			END_POWER_LINE_HURT = ImageIO.read(Class.class.getResourceAsStream("/game_objects/end_power_line_hurt.png"));
			MID_POWER_LINE_FIXED = ImageIO.read(Class.class.getResourceAsStream("/game_objects/mid_power_line_fixed.png"));
			MID_POWER_LINE_HURT = ImageIO.read(Class.class.getResourceAsStream("/game_objects/mid_power_line_hurt.png"));
			START_POWER_LINE_FIXED = ImageIO.read(Class.class.getResourceAsStream("/game_objects/start_power_line_fixed.png"));
			START_POWER_LINE_HURT = ImageIO.read(Class.class.getResourceAsStream("/game_objects/start_power_line_hurt.png"));

			CLOUD_STATE_1_SHEET = ImageIO.read(Class.class.getResourceAsStream("/game_objects/C1SS.png"));
			CLOUD_STATE_2_SHEET = ImageIO.read(Class.class.getResourceAsStream("/game_objects/C2SS.png"));
			CLOUD_STATE_3_SHEET = ImageIO.read(Class.class.getResourceAsStream("/game_objects/C3SS.png"));
			
			WINDMIL_HURT = ImageIO.read(Class.class.getResourceAsStream("/game_objects/windmil_hurt.png"));
			WINDMIL_FIXED = ImageIO.read(Class.class.getResourceAsStream("/game_objects/windmil_fixed.png"));
			
			POWER_PLANT_HURT_SHEET = ImageIO.read(Class.class.getResourceAsStream("/game_objects/power_plant_hurt.png"));
			POWER_PLANT_FIXED = ImageIO.read(Class.class.getResourceAsStream("/game_objects/power_plant_fixed.png"));
			ENERGY_STATION_SHEET = ImageIO.read(Class.class.getResourceAsStream("/game_objects/energy_station.png"));
			
			BOOM_1_SHEET = ImageIO.read(Class.class.getResourceAsStream("/booms/boom.png"));
			WATER_PICKUP = ImageIO.read(Class.class.getResourceAsStream("/game_objects/water.png"));
			
			FIRE_SHEET = ImageIO.read(Class.class.getResourceAsStream("/booms/fire.png"));
			LIGHTNING_SHEET_1 = ImageIO.read(Class.class.getResourceAsStream("/booms/lightning1.png"));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
