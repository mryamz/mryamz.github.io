package states;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.event.MouseEvent;

import main.AppPanel;
import ui.ImageButton;
import ui.Images;
import ui.OnClickListener;
import ui.UIElementManager;

public class MenuState implements AppState {

	private UIElementManager uei;
	private ImageButton play_btn;
	private long startTime = System.nanoTime();
	
	private String title = "Power Savage";
	private String subtitle = "kill the city's power";

	public MenuState() {
		uei = new UIElementManager();

		int[] xCoords = { AppPanel.WIDTH / 2 - 70, AppPanel.WIDTH / 2 + 10, AppPanel.WIDTH / 2 + 50, AppPanel.WIDTH / 2 + 80, AppPanel.WIDTH / 2 + 60, AppPanel.WIDTH / 2 + 33, AppPanel.WIDTH / 2, AppPanel.WIDTH / 2 - 60 };
		int[] yCoords = { AppPanel.HEIGHT / 2 - 10, AppPanel.HEIGHT / 2 - 60, AppPanel.HEIGHT / 2 - 40, AppPanel.HEIGHT / 2, AppPanel.HEIGHT / 2 + 30, AppPanel.HEIGHT / 2 + 50, AppPanel.HEIGHT / 2 + 59, AppPanel.HEIGHT / 2 + 50 };

		int bw = Images.PLAY_BTN_IDLE.getWidth();
		int bh = Images.PLAY_BTN_IDLE.getHeight();
		play_btn = new ImageButton(AppPanel.WIDTH / 2 - bw / 2, AppPanel.HEIGHT / 2 - bh / 2, xCoords, yCoords, Images.PLAY_BTN_PUSHED, Images.PLAY_BTN_IDLE);

		play_btn.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick() {
				AppStateManager.setAppState(new PlayState());
				
			}
		});
		
		uei.add(play_btn);
	}

	@Override
	public void update() {
		uei.update();
		if(play_btn.isHovering()) {
			
			long elapsedTime = (System.nanoTime() - startTime) / 1_000_000;
			
			float shiftX = (float) (2 * Math.sin(elapsedTime * Math.PI / 1000));
			float shiftY = (float) (3 * Math.sin(elapsedTime * Math.PI / 250));
			
			play_btn.shiftPolys((int) shiftX, (int) shiftY);
		}
	}

	@Override
	public void draw(Graphics2D g2) {
		g2.setColor(new Color(56, 222, 255));
		g2.fillRect(0, 0, AppPanel.WIDTH, AppPanel.HEIGHT);
		g2.drawImage(Images.MENU_BG, 0, AppPanel.HEIGHT - Images.MENU_BG.getHeight(), null);
		uei.draw(g2);
		
		g2.setColor(Color.WHITE);
		g2.setFont(new Font("Arial", Font.PLAIN, 76));
		g2.drawString(title, AppPanel.WIDTH - 560, 150);
		g2.setFont(new Font("Arial", Font.PLAIN, 32));
		g2.drawString(subtitle, AppPanel.WIDTH - 330, 200);
	}

	@Override
	public void keyPressed(int keycode) {
	}

	@Override
	public void keyReleased(int keycode) {

	}

	@Override
	public void mouseMoved(MouseEvent e) {
		uei.mouseMoved(e);
	}

	@Override
	public void mousePressed(MouseEvent e) {
		uei.mousePressed(e);
	}

	@Override
	public void mouseReleased(MouseEvent e) {
		uei.mouseReleased(e);
	}

}
