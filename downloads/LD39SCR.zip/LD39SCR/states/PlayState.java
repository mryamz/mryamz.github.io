package states;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.event.MouseEvent;

import anim.Background;
import game_objects.Player;
import main.AppPanel;
import ui.Images;
import ui.NotificationManager;
import ui.ProgressBar;
import ui.UIElementManager;
import world.Camera;
import world.World;

public class PlayState implements AppState {

	private World world;
	private Player player;
	private Background bg;
	
	private UIElementManager uiem;
	ProgressBar stormPoints = new ProgressBar(20, 20, 325, 50, new Color(0x00bfff), new Color(0xbfefff));
	ProgressBar cityPower = new ProgressBar(20, AppPanel.HEIGHT - 70, AppPanel.WIDTH - 40, 50, new Color(0x00bfff), new Color(0xbfefff));
	ProgressBar playerhealth = new ProgressBar(AppPanel.WIDTH - 325 - 20, 20, 325, 50, new Color(0x00bfff), new Color(0xbfefff));

	public PlayState() {
		NotificationManager.getInstance().setTextColor(new Color(0xbfefff));
		player = new Player();
		world = new World(player);
		uiem = new UIElementManager();
		
		uiem.add(stormPoints);
		uiem.add(cityPower);
		uiem.add(playerhealth);
		
		bg = new Background(Images.PLAY_BG);
	}

	@Override
	public void update() {
		bg.update(-player.getDx());
		Camera.getInstance().follow(player);
		world.update();
		player.update();
		
		if(player.getCurrentState() == 0)
			stormPoints.setText("Cute Cloud (Harmless)");
		
		if(player.getCurrentState() == 1)
			stormPoints.setText("Rain Cloud (Harmless)");
		
		if(player.getCurrentState() == 2)
			stormPoints.setText("Thunder Cloud (Violent)");
		
		stormPoints.setPercentage(player.getStormPoints() / (double) player.getMaxStormPoints());
		
		double cityPercent = world.calculateCityPower() / (double) world.getMax_city_power();
		cityPower.setPercentage(cityPercent);
		
		cityPower.setText("City's Power: " + (int) (cityPercent * 100) + "%" + (cityPercent < 0.4 ? " Running out of Power!" : " Running Fine."));
		
		
		
		double health = player.getHealth() / (double) player.getMAX_HEALTH();
		playerhealth.setPercentage(health);
		playerhealth.setText("Health: " + (health * 100) + "%");
		
		uiem.update();
		
		
		if(player.getHealth() <= 0) {
			NotificationManager.getInstance().queueNotif("You Lost. Try Again?", 8000);
			AppStateManager.setAppState(new MenuState());
		}
		
		if(world.calculateCityPower() < 0) {
			NotificationManager.getInstance().queueNotif("You Won. Good job. Try Again?", 8000);
			AppStateManager.setAppState(new MenuState());
		}
	}

	@Override
	public void draw(Graphics2D g2) {
		g2.setColor(new Color(56, 222, 255));
		g2.fillRect(0, 0, AppPanel.WIDTH, AppPanel.HEIGHT);
		bg.draw(g2);

		world.draw(g2);
		player.draw(g2);
		uiem.draw(g2);
	}

	@Override
	public void keyPressed(int keycode) {
		player.keyPressed(keycode);
	}

	@Override
	public void keyReleased(int keycode) {
		player.keyReleased(keycode);
	}

	@Override
	public void mouseMoved(MouseEvent e) {

	}

	@Override
	public void mousePressed(MouseEvent e) {

	}

	@Override
	public void mouseReleased(MouseEvent e) {

	}

}
