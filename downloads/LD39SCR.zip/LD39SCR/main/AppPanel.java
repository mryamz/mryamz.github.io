package main;

import java.awt.Dimension;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.awt.image.BufferedImage;

import javax.swing.JPanel;

import states.AppStateManager;
import states.MenuState;
import ui.NotificationManager;

public class AppPanel extends JPanel implements Runnable, KeyListener, MouseListener, MouseMotionListener {
	private static final long serialVersionUID = 1L;

	public static final int WIDTH = 800;
	public static final int HEIGHT = 600;

	private Thread thread;

	private BufferedImage img;
	private Graphics2D g2;

	private long startTime = System.nanoTime();
	private int fpsTarget = (int) (1000d / 60d);

	@Override
	public void addNotify() {
		super.addNotify();

		requestFocus();
		addKeyListener(this);
		addMouseListener(this);
		addMouseMotionListener(this);

		setPreferredSize(new Dimension(WIDTH, HEIGHT));

		img = new BufferedImage(WIDTH, HEIGHT, BufferedImage.TYPE_INT_RGB);
		g2 = img.createGraphics();

		thread = new Thread(this, "Game Thread");
		thread.start();
	}

	@Override
	public void run() {

		g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
		g2.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);

		AppStateManager.setAppState(new MenuState());
		
		NotificationManager.getInstance().queueNotif("Welcome to Power Savage (F1 for debug mode)", 5000);

		while (true) {
			long elapsed = (System.nanoTime() - startTime) / 1000000;
			if (elapsed > fpsTarget) {
				getGraphics().drawImage(img, 0, 0, WIDTH, HEIGHT, null);

				AppStateManager.getAppState().update();
				NotificationManager.getInstance().update();

				AppStateManager.getAppState().draw(g2);
				NotificationManager.getInstance().draw(g2);

				startTime = System.nanoTime();
			}
		}
	}

	@Override
	public void mouseDragged(MouseEvent e) {

	}

	@Override
	public void mouseMoved(MouseEvent e) {
		AppStateManager.getAppState().mouseMoved(e);
	}

	@Override
	public void mouseClicked(MouseEvent e) {

	}

	@Override
	public void mouseEntered(MouseEvent e) {

	}

	@Override
	public void mouseExited(MouseEvent e) {

	}

	@Override
	public void mousePressed(MouseEvent e) {
		AppStateManager.getAppState().mousePressed(e);

	}

	@Override
	public void mouseReleased(MouseEvent e) {
		AppStateManager.getAppState().mouseReleased(e);

	}

	@Override
	public void keyPressed(KeyEvent e) {
		AppStateManager.getAppState().keyPressed(e.getKeyCode());

	}

	@Override
	public void keyReleased(KeyEvent e) {
		AppStateManager.getAppState().keyReleased(e.getKeyCode());

		if (e.getKeyCode() == KeyEvent.VK_ESCAPE) {
			System.out.println("Gameloop successfully broke :)");
			System.exit(0);
		}
		

		if (e.getKeyCode() == KeyEvent.VK_F1) {
			System.out.println("Debug turned " + (!Main.isDebug ?  "on :)" : "off :("));
			Main.isDebug = !Main.isDebug;
		}
	}

	@Override
	public void keyTyped(KeyEvent e) {

	}
}
