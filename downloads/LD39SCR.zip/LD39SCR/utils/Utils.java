package utils;

import java.awt.Polygon;
import java.awt.Shape;
import java.awt.geom.Area;
import java.util.Random;

public class Utils {

	public static boolean isOverlappingWith(Polygon bounds1, Polygon bounds2) {
		Area area = new Area(bounds2);
		area.intersect(new Area(bounds1));
		return !area.isEmpty();
	}

	public static boolean testIntersection(Shape shapeA, Shape shapeB) {
		Area areaA = new Area(shapeA);
		areaA.intersect(new Area(shapeB));
		return !areaA.isEmpty();
	}

	public static int randomRange(int min, int max) {
		return min + new Random().nextInt((max - min) + 1);
	}
}
