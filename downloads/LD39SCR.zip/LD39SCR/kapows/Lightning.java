package kapows;

import java.awt.Graphics2D;
import java.awt.Polygon;

import anim.SpriteSheetPlayer;
import game_objects.GameObject;
import ui.Images;
import utils.Utils;
import world.Camera;

public class Lightning extends GameObject {

	private SpriteSheetPlayer ssp;

	public Lightning(float x, float y) {
		ssp = new SpriteSheetPlayer(Images.LIGHTNING_SHEET_1, 350, Images.LIGHTNING_SHEET_1.getHeight(), Utils.randomRange(60, 170), 6);
		this.x = x;
		this.y = y;
	}
	
	public SpriteSheetPlayer getSsp() {
		return ssp;
	}

	@Override
	public void update() {
		ssp.update(0);
	}

	@Override
	public void draw(Graphics2D g) {
		g.drawImage(ssp.getCurrentFrame(), (int) x + 50 - (int) Camera.getInstance().getScrollX(), (int) y + 50 - (int) Camera.getInstance().getScrollY(), 350 / 3, Images.LIGHTNING_SHEET_1.getHeight() / 3, null);
	}

	@Deprecated
	@Override
	public Polygon getBounds() {
		return null;
	}
}
