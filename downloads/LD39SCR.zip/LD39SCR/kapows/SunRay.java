package kapows;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Polygon;
import java.awt.Stroke;

import game_objects.GameObject;
import world.Camera;

public class SunRay extends GameObject {

	private float dx, dy;

	private float angle;
	private float length;

	private float x2;
	private float y2;

	public SunRay(float x1, float y1, float length, float angle) {
		this.angle = angle;
		this.length = length;

		this.x = x1;
		this.y = y1;

	}

	@Override
	public void update() {

		dx = -(float) Math.cos(Math.toRadians(angle)) * length;
		dy = -(float) Math.sin(Math.toRadians(angle)) * length;

		float dist = (float) Math.sqrt((dx * dx) + (dy * dy));

		dx /= dist * 1.5;
		dy /= dist * 1.5;

		dx *= 6;
		dy *= 6;

		x += dx;
		y += dy;

		x2 = (float) Math.cos(Math.toRadians(angle)) * length;
		y2 = (float) Math.sin(Math.toRadians(angle)) * length;

		if (y > -600)
			shouldRemove = true;

		if (x < -50) {
			shouldRemove = true;
		}
	}

	@Override
	public void draw(Graphics2D g) {
		g.setColor(Color.YELLOW);
		Stroke old = g.getStroke();
		g.setStroke(new BasicStroke(3.2f));
		g.drawLine((int) (x - Camera.getInstance().getScrollX()), (int) (y - Camera.getInstance().getScrollY()), (int) (x + x2 - Camera.getInstance().getScrollX()), (int) (y + y2 - Camera.getInstance().getScrollY()));
		g.setStroke(old);
	}
	
	public float getX2() {
		return x2;
	}
	public float getY2() {
		return y2;
	}

	@Override
	public Polygon getBounds() {
		return null;
	}

}
