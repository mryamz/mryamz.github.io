package game_objects;

import java.awt.Graphics2D;
import java.util.ArrayList;
import java.util.List;

public class GameObjectManager {

	private List<GameObject> gameobjects = new ArrayList<>();

	public void update() {
		try {
			for (GameObject gameObject : gameobjects) {
				gameObject.update();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void draw(Graphics2D g2) {
		try {
			for (GameObject gameObject : gameobjects) {
				gameObject.draw(g2);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public List<GameObject> getGameObjects() {
		return gameobjects;
	}
}
