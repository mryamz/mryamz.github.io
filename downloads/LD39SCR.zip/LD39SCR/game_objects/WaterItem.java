package game_objects;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Polygon;

import main.Main;
import ui.Images;
import world.Camera;

public class WaterItem extends GameObject {

	private int[] xpoints = { 0 };
	private int[] ypoints = { 0 };

	public WaterItem(float x, float y) {
		this.x = x;
		this.y = y;
	}

	@Override
	public void update() {
		xpoints = new int[] { (int) (x + 10), (int) (x + 50), (int) (x + 78), (int) (x + 58), (int) (x + 30), (int) (x + 0) };
		ypoints = new int[] { (int) (y + 10), (int) (y + 0), (int) (y + 40), (int) (y + 70), (int) (y + 80), (int) (y + 50) };
	}

	@Override
	public void draw(Graphics2D g) {
		g.drawImage(Images.WATER_PICKUP, (int) (x - Camera.getInstance().getScrollX()), (int) (y - Camera.getInstance().getScrollY()), 311 / 4, 387 / 4, null);

		if (Main.isDebug) {
			g.setColor(Color.RED);
			g.drawPolygon(getBounds());
		}
	}

	@Override
	public Polygon getBounds() {
		int[] xp = new int[xpoints.length];
		int[] yp = new int[ypoints.length];

		for (int i = 0; i < yp.length; i++) {
			xp[i] = (int) (xpoints[i] - Camera.getInstance().getScrollX());
			yp[i] = (int) (ypoints[i] - Camera.getInstance().getScrollY());
		}

		return new Polygon(xp, yp, xp.length);
	}

}
