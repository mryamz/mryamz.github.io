package game_objects;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Polygon;

import anim.SpriteSheetPlayer;
import main.Main;
import ui.Images;
import ui.NotificationManager;
import world.Camera;

public class EnergyStation extends GameObject {

	private boolean isHurt;

	private final int MAX_HEALTH = 300;
	private int health = MAX_HEALTH;
	private int[] xpoints, ypoints;

	private int state = 1;

	private SpriteSheetPlayer ssp;

	public EnergyStation(float x, float y) {
		super.x = x;
		super.y = y;
		ssp = new SpriteSheetPlayer(Images.ENERGY_STATION_SHEET, 435, 286, 120, new int[] { 1, 8, 8 });
		xpoints = new int[] { (int) x + 0, (int) x + 30, (int) x + 70, (int) x + 100, (int) x + 150, (int) x + 240, (int) x + 275, (int) x + 320, (int) x + 350, (int) x + 420 };
		ypoints = new int[] { (int) y + 286, (int) y + 60, (int) y + 40, (int) y + 140, (int) y + 250, (int) y + 200, (int) y + 0, (int) y + 20, (int) y + 200, (int) y + 280 };

	}

	@Override
	public void update() {

		if (health < 0) {
			if (!isHurt)
				onHurt();
			isHurt = true;
		}

		ssp.update(state);
		if(health < 0) {
			health = 0;
		}
	}

	public int getHealth() {
		return health;
	}

	@Override
	public void draw(Graphics2D g) {
		if (!isHurt)
			g.drawImage(ssp.getCurrentFrame(), (int) (x - Camera.getInstance().getScrollX()), (int) (y - Camera.getInstance().getScrollY()), null);
		else
			g.drawImage(ssp.getCurrentFrame(), (int) (x - Camera.getInstance().getScrollX()), (int) (y - Camera.getInstance().getScrollY()), null);

		if (Main.isDebug && !isHurt) {
			g.setColor(Color.RED);
			g.drawPolygon(getBounds());
		}
	}

	@Override
	public Polygon getBounds() {

		int[] xp = new int[xpoints.length];
		int[] yp = new int[ypoints.length];

		for (int i = 0; i < yp.length; i++) {
			xp[i] = (int) (xpoints[i] - Camera.getInstance().getScrollX());
			yp[i] = (int) (ypoints[i] - Camera.getInstance().getScrollY());
		}

		return new Polygon(xp, yp, xp.length);
	}

	public boolean isHurt() {
		return isHurt;
	}

	public void modHealth(int amt) {
		health += amt;
	}

	private void onHurt() {
		state = 2;
		NotificationManager.getInstance().queueNotif("Energy Processing Plant Ruined", 2000);
	}

}
