package game_objects;

import java.awt.Graphics2D;
import java.awt.Polygon;

public abstract class GameObject {
	
	public boolean shouldRemove;

	protected float x, y;

	public abstract void update();

	public abstract void draw(Graphics2D g);

	public abstract Polygon getBounds();

	public float getX() {
		return x;
	}

	public float getY() {
		return y;
	}
}
