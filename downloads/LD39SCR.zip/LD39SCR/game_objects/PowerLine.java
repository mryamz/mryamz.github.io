package game_objects;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Polygon;

import main.Main;
import ui.Images;
import ui.NotificationManager;
import world.Camera;

public class PowerLine extends GameObject {

	public static final int TYPE_START = 1;
	public static final int TYPE_MID = 2;
	public static final int TYPE_END = 3;

	private int type = -1;

	private boolean isHurt;

	private final int MAX_HEALTH = 100;
	private int health = MAX_HEALTH;
	int[] xpoints, ypoints;

	public PowerLine(int type, float x, float y) {

		this.type = type;
		super.x = x;
		super.y = y;
		
		switch (type) {
		case TYPE_START:
			xpoints = new int[] { (int) (x + 0), (int) (x + 70), (int) (x + 140), (int) (x + 140), (int) (x + 80), (int) (x + 80), (int) (x + 60), (int) (x + 60), (int) (x + 0) };
			ypoints = new int[] { (int) (y + 10), (int) (y + 0), (int) (y + 10), (int) (y + 40), (int) (y + 40), (int) (y + 208), (int) (y + 208), (int) (y + 40), (int) (y + 40) };
			break;
		case TYPE_MID:
			xpoints = new int[] { (int) (x + 0), (int) (x + 70), (int) (x + 140), (int) (x + 140), (int) (x + 80), (int) (x + 80), (int) (x + 60), (int) (x + 60), (int) (x + 0) };
			ypoints = new int[] { (int) (y + 10), (int) (y + 0), (int) (y + 10), (int) (y + 40), (int) (y + 40), (int) (y + 208), (int) (y + 208), (int) (y + 40), (int) (y + 40) };
			for (int i = 0; i < xpoints.length; i++) {
				xpoints[i] += 175;
			}
			break;
		case TYPE_END:
			xpoints = new int[] { (int) (x + 0), (int) (x + 70), (int) (x + 140), (int) (x + 140), (int) (x + 80), (int) (x + 80), (int) (x + 60), (int) (x + 60), (int) (x + 0) };
			ypoints = new int[] { (int) (y + 10), (int) (y + 0), (int) (y + 10), (int) (y + 40), (int) (y + 40), (int) (y + 208), (int) (y + 208), (int) (y + 40), (int) (y + 40) };
			for (int i = 0; i < xpoints.length; i++) {
				xpoints[i] += 175;
			}
			break;
		}

	}

	@Override
	public void update() {
		if (health < 0) {
			if(!isHurt) 
				onHurt();
			isHurt = true;
		}
		
		if(health < 0) {
			health = 0;
		}
	}

	@Override
	public void draw(Graphics2D g) {

		switch (type) {
		case TYPE_START:
			if (!isHurt)
				g.drawImage(Images.START_POWER_LINE_FIXED, (int) ((x - Camera.getInstance().getScrollX())), (int) (y - Camera.getInstance().getScrollY()), null);
			else
				g.drawImage(Images.START_POWER_LINE_HURT, (int) (x - Camera.getInstance().getScrollX()), (int) (y - Camera.getInstance().getScrollY()), null);
			break;
		case TYPE_MID:
			if (!isHurt)
				g.drawImage(Images.MID_POWER_LINE_FIXED, (int) (x - Camera.getInstance().getScrollX()), (int) (y - Camera.getInstance().getScrollY()), null);
			else
				g.drawImage(Images.MID_POWER_LINE_HURT, (int) (x - Camera.getInstance().getScrollX()), (int) (y - Camera.getInstance().getScrollY()), null);
			break;
		case TYPE_END:
			if (!isHurt)
				g.drawImage(Images.END_POWER_LINE_FIXED, (int) (x - Camera.getInstance().getScrollX()), (int) (y - Camera.getInstance().getScrollY()), null);
			else
				g.drawImage(Images.END_POWER_LINE_HURT, (int) (x - Camera.getInstance().getScrollX()), (int) (y - Camera.getInstance().getScrollY()), null);
			break;
		default:
			break;
		}

		if (Main.isDebug && !isHurt) {
			g.setColor(Color.RED);
			g.drawPolygon(getBounds());
		}
	}

	@Override
	public Polygon getBounds() {

		int[] xp = new int[xpoints.length];
		int[] yp = new int[ypoints.length];

		for (int i = 0; i < yp.length; i++) {
			xp[i] = (int) (xpoints[i] - Camera.getInstance().getScrollX());
			yp[i] = (int) (ypoints[i] - Camera.getInstance().getScrollY());
		}

		return new Polygon(xp, yp, 9);
	}
	
	public boolean isHurt() {
		return isHurt;
	}

	public void modHealth(int amt) {
		health += amt;
	}
	
	private void onHurt() {
		if((type == TYPE_START) || (type == TYPE_END)) {
			y -= 10;
		}
		NotificationManager.getInstance().queueNotif("Powerline Destroyed", 1000);

	}
	
	public int getHealth() {
		return health;
	}
}
