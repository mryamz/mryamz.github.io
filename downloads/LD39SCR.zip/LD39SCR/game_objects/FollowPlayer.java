package game_objects;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Polygon;
import java.awt.Rectangle;
import java.util.concurrent.ThreadLocalRandom;

import anim.OnCompleteListener;
import anim.SpriteSheetPlayer;
import kapows.Lightning;
import main.AppPanel;
import main.Main;
import ui.Images;
import utils.Utils;
import world.Camera;
import world.World;

public class FollowPlayer extends GameObject {

	private int stormPoints;
	private float vx, vy;
	private int currentState = 0; /* [0-2] */
	private SpriteSheetPlayer[] sheets;

	private int shouldRunThroughAnim = 0; /* 1 or 0 */

	private long blinkTimer = System.nanoTime();
	private int blinkDelay = ThreadLocalRandom.current().nextInt(500, 1000);

	private int[] xpoints = { 20, 75, 146, 120, 35, 0 };
	private int[] ypoints = { 20, 0, 40, 80, 80, 40 };

	private Player player;

	private float max_speed = ThreadLocalRandom.current().nextInt(5, 9);

	private int xTrgtOff = Utils.randomRange(-175, 175);

	private World world;
	public boolean isAttacking;
	private Rectangle attacktangle;

	private long attackTimer = System.nanoTime();
	private int attackDelay = Utils.randomRange(4500, 10000);

	public FollowPlayer() {
		attacktangle = new Rectangle(0, 0, 146, AppPanel.HEIGHT / 2);

		sheets = new SpriteSheetPlayer[3];
		sheets[0] = new SpriteSheetPlayer(Images.CLOUD_STATE_1_SHEET, 365, 208, 125, 1, 6);
		sheets[0].setOnCompleteListener(new OnCompleteListener() {
			@Override
			public void onComplete(int row) {
				if (row == 1) {
					blinkDelay = ThreadLocalRandom.current().nextInt(1250, 4000);

					shouldRunThroughAnim = 0;
				}
			}
		});

		sheets[1] = new SpriteSheetPlayer(Images.CLOUD_STATE_2_SHEET, 365, 208, 115, 1, 5);
		sheets[1].setOnCompleteListener(new OnCompleteListener() {
			@Override
			public void onComplete(int row) {
				if (row == 1) {
					blinkDelay = ThreadLocalRandom.current().nextInt(1250, 2250);

					shouldRunThroughAnim = 0;
				}
			}
		});

		sheets[2] = new SpriteSheetPlayer(Images.CLOUD_STATE_3_SHEET, 365, 208, 90, 1, 10);
		sheets[2].setOnCompleteListener(new OnCompleteListener() {
			@Override
			public void onComplete(int row) {
				if (row == 1) {
					blinkDelay = ThreadLocalRandom.current().nextInt(1250, 4000);

					shouldRunThroughAnim = 0;
				}
			}
		});
	}

	public int getStormPoints() {
		return stormPoints;
	}

	public int getCurrentState() {
		return currentState;
	}

	public int getMaxStormPoints() {
		return 300;
	}

	@Override
	public void update() {

		float dx = player.x - x + xTrgtOff;
		float dy = player.y - y;

		float dist = (float) Math.sqrt((dx * dx) + (dy * dy));

		dx /= dist * 1.5 + 1;
		dy /= dist * 1.5 + 1;

		vx += dx * .5f;
		vy += dy * .5f;

		float velocity = (float) Math.sqrt((vx * vx) + (vy * vy));

		if (velocity > max_speed) {
			vx = (vx * max_speed) / velocity;
			vy = (vy * max_speed) / velocity;
		}

		long elapsed = (System.nanoTime() - blinkTimer) / 1_000_000;
		if (elapsed > blinkDelay) {
			shouldRunThroughAnim = 1;
			blinkTimer = System.nanoTime();
		}

		attacktangle.x = (int) (x - Camera.getInstance().getScrollX());
		attacktangle.y = (int) (y - Camera.getInstance().getScrollY());
		
		if (!isAttacking) {
			x += (int) vx;
			y += (int) vy;


			for (int i = 0; i < 6; i++) {
				xpoints[i] += (int) vx;
				ypoints[i] += (int) vy;
			}
		}


		sheets[currentState].update(shouldRunThroughAnim);

		if (stormPoints < 100) {
			currentState = 0;
		} else if (stormPoints >= 100 && stormPoints < 200) {
			currentState = 1;
		}

		if (stormPoints > getMaxStormPoints()) {
			currentState = 2;
			stormPoints = getMaxStormPoints();
		}
		

		long elapsedAttack = (System.nanoTime() - attackTimer) / 1_000_000;
		if (elapsedAttack > attackDelay ) {
			if (!isAttacking && currentState == 2)
				launchAttack(false);
		}
	}

	public Rectangle getAttacktangle() {
		return attacktangle;
	}

	public void launchAttack(boolean fromPlayer) {
		Lightning l1 = new Lightning(x - 25 + Utils.randomRange(-40, 40), y + 30);
		world.getLightnings().add(l1);
		world.isCollisionsWithFollowPlayerAttackAndBuildings(this);

		isAttacking = true;
		l1.getSsp().setOnCompleteListener(new OnCompleteListener() {
			@Override
			public void onComplete(int row) {
				l1.shouldRemove = true;
				Lightning l2 = new Lightning(x - 25 + Utils.randomRange(-40, 40), y + 30);
				world.getLightnings().add(l2);
				world.isCollisionsWithFollowPlayerAttackAndBuildings(FollowPlayer.this);

				l2.getSsp().setOnCompleteListener(new OnCompleteListener() {
					@Override
					public void onComplete(int row) {
						l2.shouldRemove = true;
						Lightning l3 = new Lightning(x - 25 + Utils.randomRange(-40, 40), y + 30);
						world.getLightnings().add(l3);
						final boolean hit = world.isCollisionsWithFollowPlayerAttackAndBuildings(FollowPlayer.this);

						l3.getSsp().setOnCompleteListener(new OnCompleteListener() {
							@Override
							public void onComplete(int row) {
								l3.shouldRemove = true;
								attackTimer = System.nanoTime();
								isAttacking = false;
								attackDelay = Utils.randomRange(40_000, 120_000);
								if (hit || fromPlayer) {
									stormPoints = 0;
								}
							}
						});
					}
				});
			}
		});
	}

	public void setWorld(World world) {
		this.world = world;
	}

	@Override
	public void draw(Graphics2D g) {
		g.drawImage(sheets[currentState].getCurrentFrame(), (int) (x - Camera.getInstance().getScrollX()), (int) (y - Camera.getInstance().getScrollY()), 146, 83, null);

		if (Main.isDebug) {
			g.setColor(Color.RED);
			g.drawPolygon(getBounds());
			g.draw(attacktangle);
		}
	}

	public void setPlayer(Player player) {
		this.player = player;
	}

	public void modStormPoints(int amt) {
		stormPoints += amt;
	}

	@Override
	public Polygon getBounds() {
		return new Polygon(new int[] { (int) (xpoints[0] - Camera.getInstance().getScrollX()), (int) (xpoints[1] - Camera.getInstance().getScrollX()), (int) (xpoints[2] - Camera.getInstance().getScrollX()), (int) (xpoints[3] - Camera.getInstance().getScrollX()), (int) (xpoints[4] - Camera.getInstance().getScrollX()), (int) (xpoints[5] - Camera.getInstance().getScrollX()) },

				new int[] { (int) (ypoints[0] - Camera.getInstance().getScrollY()), (int) (ypoints[1] - Camera.getInstance().getScrollY()), (int) (ypoints[2] - Camera.getInstance().getScrollY()), (int) (ypoints[3] - Camera.getInstance().getScrollY()), (int) (ypoints[4] - Camera.getInstance().getScrollY()), (int) (ypoints[5] - Camera.getInstance().getScrollY()) }, 6);
	}

}
