package game_objects;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Polygon;

import anim.SpriteSheetPlayer;
import main.Main;
import ui.Images;
import ui.NotificationManager;
import world.Camera;

public class PowerPlant extends GameObject {

	private boolean isHurt;

	private final int MAX_HEALTH = 400;
	private int health = MAX_HEALTH;
	private int[] xpoints, ypoints;
	
	private SpriteSheetPlayer ssp;

	public PowerPlant(float x, float y) {
		super.x = x;
		super.y = y;
		ssp = new SpriteSheetPlayer(Images.POWER_PLANT_HURT_SHEET, 700, Images.POWER_PLANT_HURT_SHEET.getHeight(), 95, 8);
		xpoints = new int[] { (int) x + 50,(int) x + 379,(int) x + 350, (int) x + 650, (int) x + 620, (int) x + 690, (int) x + 0, (int) x + 80};
		ypoints = new int[] { (int) y + 0,(int) y + 0,(int) y + 80, (int) y + 90, (int) y + 300, (int) y + 480, (int) y + 480, (int) y + 240};
	}
	public int getHealth() {
		return health;
	}
	@Override
	public void update() {

		if (health < 0) {
			if (!isHurt)
				onHurt();
			isHurt = true;
		}
		
		ssp.update(0);
		
		if(health < 0) {
			health = 0;
		}
	}

	@Override
	public void draw(Graphics2D g) {
		if (!isHurt)
			g.drawImage(Images.POWER_PLANT_FIXED, (int) (x - Camera.getInstance().getScrollX()), (int) (y - Camera.getInstance().getScrollY()), null);
		else
			g.drawImage(ssp.getCurrentFrame(), (int) (x - Camera.getInstance().getScrollX()), (int) (y - Camera.getInstance().getScrollY()), null);

		if (Main.isDebug && !isHurt) {
			g.setColor(Color.RED);
			g.drawPolygon(getBounds());
		}
	}

	@Override
	public Polygon getBounds() {

		int[] xp = new int[xpoints.length];
		int[] yp = new int[ypoints.length];

		for (int i = 0; i < yp.length; i++) {
			xp[i] = (int) (xpoints[i] - Camera.getInstance().getScrollX());
			yp[i] = (int) (ypoints[i] - Camera.getInstance().getScrollY());
		}

		return new Polygon(xp, yp, xp.length);
	}

	public boolean isHurt() {
		return isHurt;
	}

	public void modHealth(int amt) {
		health += amt;
	}

	private void onHurt() {
		y -= Images.POWER_PLANT_HURT_SHEET.getHeight() - Images.POWER_PLANT_FIXED.getHeight();
		NotificationManager.getInstance().queueNotif("Powerplant Destroyed", 1000);
	}
}
