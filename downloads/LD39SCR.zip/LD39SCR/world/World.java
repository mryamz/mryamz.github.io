package world;

import java.awt.Graphics2D;
import java.util.List;
import java.util.Random;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.ThreadLocalRandom;

import game_objects.EnergyStation;
import game_objects.FollowPlayer;
import game_objects.GameObjectManager;
import game_objects.Player;
import game_objects.PowerLine;
import game_objects.PowerPlant;
import game_objects.WaterItem;
import game_objects.Windmil;
import kapows.Boom;
import kapows.Lightning;
import kapows.SunRay;
import main.AppPanel;
import ui.Images;
import utils.Utils;

public class World {

	public static final int MAX_WIDTH = 4500;
	public static final int MAX_HEIGTH = AppPanel.HEIGHT * 2;

	private Random rand = new Random();

	private List<PowerLine> powerlines;
	private List<Windmil> windmils;
	private List<WaterItem> waters;
	private List<FollowPlayer> followers;
	private List<Lightning> lightnings;
	private List<PowerPlant> powerplants;
	private List<EnergyStation> energyfarm;
	private List<SunRay> rays;

	private GameObjectManager gom;
	private Player player;

	private float endX;

	private int max_city_power;

	public World(Player player) {
		this.player = player;
		powerlines = new CopyOnWriteArrayList<>();
		rays = new CopyOnWriteArrayList<>();
		powerplants = new CopyOnWriteArrayList<>();
		energyfarm = new CopyOnWriteArrayList<>();
		windmils = new CopyOnWriteArrayList<>();
		waters = new CopyOnWriteArrayList<>();
		followers = new CopyOnWriteArrayList<>();
		lightnings = new CopyOnWriteArrayList<>();
		gom = new GameObjectManager();
		player.setWorld(this);
		generateWorld();
	}

	public void generateWorld() {
		makePowerlines();
		makeWindmils();
		makePowerPlants();
		makeEnergyProcessFarm();
		makePowerlines();

		for (PowerLine pl : powerlines) {
			max_city_power += pl.getHealth();
		}

		for (Windmil wm : windmils) {
			max_city_power += wm.getHealth();
		}

		for (PowerPlant pp : powerplants) {
			max_city_power += pp.getHealth();
		}

		for (EnergyStation es : energyfarm) {
			max_city_power += es.getHealth();
		}

		for (int i = 0; i < 20; i++) {
			spawnRaysInit();
		}
	}

	public int calculateCityPower() {
		int city_power = 0;
		for (PowerLine pl : powerlines) {
			city_power += pl.getHealth();
		}

		for (Windmil wm : windmils) {
			city_power += wm.getHealth();
		}

		for (PowerPlant pp : powerplants) {
			city_power += pp.getHealth();
		}

		for (EnergyStation es : energyfarm) {
			city_power += es.getHealth();
		}
		return city_power;
	}

	private void makePowerlines() {
		float startX = endX;
		PowerLine pl_start = new PowerLine(PowerLine.TYPE_START, startX, AppPanel.HEIGHT - 229);
		powerlines.add(pl_start);
		int number = 1;
		for (int i = 0; i < number; i++) {
			PowerLine pl_mid = new PowerLine(PowerLine.TYPE_MID, startX + Images.START_POWER_LINE_FIXED.getWidth() + (i * Images.MID_POWER_LINE_FIXED.getWidth()), AppPanel.HEIGHT - 229);
			powerlines.add(pl_mid);
		}
		endX = startX + Images.START_POWER_LINE_FIXED.getWidth() + (number * Images.MID_POWER_LINE_FIXED.getWidth());
		PowerLine pl_end = new PowerLine(PowerLine.TYPE_END, endX, AppPanel.HEIGHT - 229);
		powerlines.add(pl_end);

		gom.getGameObjects().addAll(powerlines);
	}

	private void makeWindmils() {
		float startX = endX;
		for (int i = 0; i < 3; i++) {
			Windmil wm = new Windmil(endX = (startX + Images.START_POWER_LINE_FIXED.getWidth() + (i * Images.WINDMIL_FIXED.getWidth())), AppPanel.HEIGHT - Images.WINDMIL_FIXED.getHeight());
			windmils.add(wm);
		}

		gom.getGameObjects().addAll(windmils);
	}

	private void makePowerPlants() {
		float startX = endX;
		for (int i = 0; i < 3; i++) {
			PowerPlant wm = new PowerPlant((startX + Images.WINDMIL_FIXED.getWidth() + (i * Images.POWER_PLANT_FIXED.getWidth())), AppPanel.HEIGHT - Images.POWER_PLANT_FIXED.getHeight());
			powerplants.add(wm);
		}

		gom.getGameObjects().addAll(powerplants);
	}

	private void makeEnergyProcessFarm() {
		float startX = endX;
		for (int i = 0; i < 3; i++) {
			EnergyStation wm = new EnergyStation(endX = (startX + Images.POWER_PLANT_FIXED.getWidth() + (i * 450)), AppPanel.HEIGHT - 286);
			energyfarm.add(wm);
		}

		endX += 600;

		gom.getGameObjects().addAll(energyfarm);
	}

	private void spawnWater() {
		if (waters.size() < 50) {
			WaterItem wi = new WaterItem(rand.nextInt(MAX_WIDTH), -ThreadLocalRandom.current().nextInt(AppPanel.HEIGHT, MAX_HEIGTH));
			waters.add(wi);
			gom.getGameObjects().add(wi);
		}
	}

	private void spawnRays() {
		if (rays.size() < 20) {
			SunRay ray = new SunRay(Utils.randomRange(0, MAX_WIDTH), -MAX_HEIGTH, 75 + Utils.randomRange(-25, 25), -45);
			rays.add(ray);
			gom.getGameObjects().add(ray);
		}
	}

	private void spawnRaysInit() {
		if (rays.size() < 20) {
			SunRay ray = new SunRay(Utils.randomRange(0, MAX_WIDTH), Utils.randomRange(-MAX_HEIGTH, -600), 75 + Utils.randomRange(-25, 25), -45);
			rays.add(ray);
			gom.getGameObjects().add(ray);
		}
	}

	// kam a kaz ee clouds to buildings
	private void checkCollionsWithFollowersAndBuildings() {
		for (PowerLine pl : powerlines) {
			for (FollowPlayer fp : followers) {
				if (Utils.isOverlappingWith(pl.getBounds(), fp.getBounds())) {

					if (pl.isHurt())
						continue;

					pl.modHealth(-10);
					followers.remove(fp);
					gom.getGameObjects().remove(fp);

					gom.getGameObjects().add(new Boom(fp.getX(), fp.getY()));
				}
			}
		}

		for (Windmil wm : windmils) {
			for (FollowPlayer fp : followers) {
				if (Utils.isOverlappingWith(wm.getBounds(), fp.getBounds())) {

					if (wm.isHurt())
						continue;

					wm.modHealth(-10);
					followers.remove(fp);
					gom.getGameObjects().remove(fp);

					gom.getGameObjects().add(new Boom(fp.getX(), fp.getY()));
				}
			}
		}

		for (EnergyStation es : energyfarm) {
			for (FollowPlayer fp : followers) {
				if (Utils.isOverlappingWith(es.getBounds(), fp.getBounds())) {

					if (es.isHurt())
						continue;

					es.modHealth(-10);
					followers.remove(fp);
					gom.getGameObjects().remove(fp);

					gom.getGameObjects().add(new Boom(fp.getX(), fp.getY()));
				}
			}
		}
	}

	private void checkCollisionsWithRays() {
		for (SunRay ray : rays) {
			for (FollowPlayer fp : followers) {
				if (fp.getBounds().contains(ray.getX() - Camera.getInstance().getScrollX(), ray.getY() - Camera.getInstance().getScrollY()) || fp.getBounds().contains(ray.getX() + ray.getX2() - Camera.getInstance().getScrollX(), ray.getY() + ray.getY2() - Camera.getInstance().getScrollY())) {
					ray.shouldRemove = true;
					fp.modStormPoints(-1);
				}
			}

			if (player.getBounds().contains(ray.getX() - Camera.getInstance().getScrollX(), ray.getY() - Camera.getInstance().getScrollY()) || player.getBounds().contains(ray.getX() + ray.getX2() - Camera.getInstance().getScrollX(), ray.getY() + ray.getY2() - Camera.getInstance().getScrollY())) {
				ray.shouldRemove = true;
				player.modHealth(-1);
			}
		}
	}

	private void checkCollisionsWithPlayerWater() {
		for (WaterItem waterItem : waters) {
			if (Utils.isOverlappingWith(waterItem.getBounds(), player.getBounds())) {

				if (player.getCurrentState() != 2) {
					waterItem.shouldRemove = true;
					player.modStormPoints(15);
					waters.remove(waterItem);
					gom.getGameObjects().remove(waterItem);

					if (followers.size() < 20) {
						FollowPlayer fp = new FollowPlayer();
						fp.setPlayer(player);
						fp.setWorld(this);
						followers.add(fp);
						gom.getGameObjects().add(fp);
					}
				}
			}
		}
	}

	private void checkCollisionsWithFollowersAndWater() {
		for (WaterItem waterItem : waters) {
			for (FollowPlayer cfp : followers) {
				if (cfp.getCurrentState() != 2)
					if (Utils.isOverlappingWith(cfp.getBounds(), waterItem.getBounds())) {
						waterItem.shouldRemove = true;
						cfp.modStormPoints(100);
						waters.remove(waterItem);
					}
			}
		}
	}

	// PLAYER to BUILDINGS
	public void checkCollisionsWithPlayerAttackAndBuildings() {
		for (PowerLine pl : powerlines) {
			if (pl.getBounds().intersects(player.getAttacktangle())) {
				pl.modHealth(-50);
			}
		}

		for (Windmil wm : windmils) {
			if (wm.getBounds().intersects(player.getAttacktangle())) {
				wm.modHealth(-50);
			}
		}

		for (PowerPlant pp : powerplants) {
			if (pp.getBounds().intersects(player.getAttacktangle())) {
				pp.modHealth(-50);
			}
		}

		for (EnergyStation es : energyfarm) {
			if (es.getBounds().intersects(player.getAttacktangle())) {
				es.modHealth(-50);
			}
		}
	}

	// FOLLOW-PLAYER to BUILDINGS
	public boolean isCollisionsWithFollowPlayerAttackAndBuildings(FollowPlayer fp) {
		for (PowerLine pl : powerlines) {
			if (pl.getBounds().intersects(fp.getAttacktangle())) {
				if (pl.isHurt())
					return false;
				pl.modHealth(-50);
				return true;
			}
		}

		for (Windmil wm : windmils) {
			if (wm.getBounds().intersects(fp.getAttacktangle())) {
				if (wm.isHurt())
					return false;
				wm.modHealth(-50);
				return true;
			}
		}

		for (PowerPlant pp : powerplants) {
			if (pp.getBounds().intersects(fp.getAttacktangle())) {
				if (pp.isHurt())
					return false;
				pp.modHealth(-50);
				return true;
			}
		}

		for (EnergyStation es : energyfarm) {
			if (es.getBounds().intersects(fp.getAttacktangle())) {
				if (es.isHurt())
					return false;
				es.modHealth(-50);
				return true;
			}
		}
		return false;
	}

	public void update() {
		gom.update();
		checkCollisionsWithPlayerWater();
		checkCollisionsWithFollowersAndWater();
		checkCollionsWithFollowersAndBuildings();
		spawnWater();
		spawnRays();
		checkCollisionsWithRays();

		gom.getGameObjects().addAll(lightnings);
		lightnings.clear();

		rays.removeIf(ray -> ray.shouldRemove);
		followers.removeIf(ray -> ray.shouldRemove);
		gom.getGameObjects().removeIf(e -> e.shouldRemove);
	}

	public List<FollowPlayer> getFollowers() {
		return followers;
	}

	public GameObjectManager getGom() {
		return gom;
	}

	public void draw(Graphics2D g2) {
		gom.draw(g2);
	}

	public void setPlayer(Player player) {
		this.player = player;
	}

	public List<Lightning> getLightnings() {
		return lightnings;
	}

	public int getMax_city_power() {
		return max_city_power;
	}
}
