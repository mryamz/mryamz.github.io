package world;

import game_objects.GameObject;
import main.AppPanel;

public class Camera {

	private Camera() {
	}

	private static Camera camera;

	public static Camera getInstance() {
		if (camera == null)
			camera = new Camera();

		return camera;
	}

	private float scrollX;
	private float scrollY;

	public void follow(GameObject gameobject) {
		scrollX = gameobject.getX() - AppPanel.WIDTH / 2 + 146 / 2;
		scrollY = gameobject.getY() - AppPanel.HEIGHT / 2 + 83 / 2;
		
		if(scrollY > 0) {
			scrollY = 0;
		}
		
		if(scrollX < 0) {
			scrollX = 0;
		}
		
		if(scrollY < -World.MAX_HEIGTH) {
			scrollY = -World.MAX_HEIGTH;
		}
		
		if(scrollX > World.MAX_WIDTH) {
			scrollX = World.MAX_WIDTH;
		}
	}

	public float getScrollX() {
		return scrollX;
	}

	public float getScrollY() {
		return scrollY;
	}
}
