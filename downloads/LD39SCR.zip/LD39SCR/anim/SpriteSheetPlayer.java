package anim;

import java.awt.image.BufferedImage;

public class SpriteSheetPlayer {

	private OnCompleteListener onCompleteListener = new OnCompleteListener() {
		@Override
		public void onComplete(int row) {
		}
	};

	private BufferedImage[][] frames;

	private int[] maxCol;

	private int currCol, currRow;

	private float frameDuration;
	private long timer = System.nanoTime();

	/**
	 * row [0] has X pics
	 * 
	 * @param sheet
	 * @param cellWidth
	 * @param cellHeight
	 * @param frameDuration
	 * @param numberOfPicsInCol
	 */
	public SpriteSheetPlayer(BufferedImage sheet, int cellWidth, int cellHeight, float frameDuration, int... numberOfPicsInCol) {
		this.frameDuration = frameDuration;
		frames = subdivide(sheet, cellWidth, cellHeight);
		maxCol = numberOfPicsInCol;
	}

	private BufferedImage[][] subdivide(BufferedImage img, int tileWidth, int tileHeight) {
		int xlength = img.getWidth() / tileWidth;
		int ylength = img.getHeight() / tileHeight;
		BufferedImage[][] answer = new BufferedImage[xlength][ylength];
		for (int i = 0; i < xlength; i++) {
			for (int j = 0; j < ylength; j++) {
				answer[i][j] = img.getSubimage(i * tileWidth, j * tileHeight, tileWidth, tileHeight);
			}
		}

		return answer;
	}

	public void update(int currRow) {
		this.currRow = currRow;
		long elasped = (System.nanoTime() - timer) / 1_000_000;
		if (elasped > frameDuration) {
			currCol++;
			if (currCol > maxCol[currRow] - 1) {
				currCol = 0;
				onCompleteListener.onComplete(currRow);
			}
			timer = System.nanoTime();
		}
	}

	public BufferedImage getCurrentFrame() {
		return frames[currCol][currRow];
	}
	
	public void reset() {
		currCol = 0;
	}

	public void setOnCompleteListener(OnCompleteListener onCompleteListener) {
		this.onCompleteListener = onCompleteListener;
	}

}
