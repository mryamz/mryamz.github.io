package anim;

public interface OnCompleteListener {

	void onComplete(int row);
}
