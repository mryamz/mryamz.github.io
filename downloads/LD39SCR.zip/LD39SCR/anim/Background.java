package anim;

import java.awt.Graphics2D;
import java.awt.image.BufferedImage;

import main.AppPanel;
import world.Camera;

public class Background {

	private BufferedImage[] bgs;
	private float[] x1;
	private float[] x2;
	private float[] x3;

	private float tween = 0.03f;

	public Background(BufferedImage... bgs) {
		this.bgs = bgs;
		x1 = new float[bgs.length];
		x2 = new float[bgs.length];
		x3 = new float[bgs.length];
		for (int i = 0; i < bgs.length; i++) {
			x1[i] = -bgs[i].getWidth();
			x2[i] = 0;
			x3[i] = bgs[i].getWidth();
		}
	}

	public void update(float dx) {
		for (int i = 0; i < bgs.length; i++) {
			float moveVal = dx * tween;
			x1[i] += moveVal;
			x2[i] += moveVal;
			x3[i] += moveVal;

			if (dx > 0) {
				if (x1[i] >= AppPanel.WIDTH - moveVal) {
					x1[i] = -AppPanel.WIDTH + moveVal;
				}

				if (x2[i] >= AppPanel.WIDTH - moveVal) {
					x2[i] = -AppPanel.WIDTH + moveVal;
				}

				if (x3[i] >= AppPanel.WIDTH - moveVal) {
					x3[i] = -AppPanel.WIDTH + moveVal;
				}
			}

			if (dx < 0) {
				if (x1[i] <= -AppPanel.WIDTH - moveVal) {
					x1[i] = AppPanel.WIDTH + moveVal;
				}
				if (x2[i] <= -AppPanel.WIDTH - moveVal) {
					x2[i] = AppPanel.WIDTH + moveVal;
				}
				if (x3[i] <= -AppPanel.WIDTH - moveVal) {
					x3[i] = AppPanel.WIDTH + moveVal;
				}

			}
		}
	}

	public void draw(Graphics2D g2) {
		for (int i = 0; i < bgs.length; i++) {
			g2.drawImage(bgs[i], (int) x1[i], (int) (-Camera.getInstance().getScrollY()) / 2, null);
			g2.drawImage(bgs[i], (int) x2[i], (int) (-Camera.getInstance().getScrollY()) / 2, null);
			g2.drawImage(bgs[i], (int) x3[i], (int) (-Camera.getInstance().getScrollY()) / 2, null);
		}
	}
}
