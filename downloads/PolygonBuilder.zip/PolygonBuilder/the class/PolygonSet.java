package mryamz.polybuilder;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

import com.badlogic.gdx.files.FileHandle;
import com.badlogic.gdx.math.Polygon;
import com.badlogic.gdx.utils.Array;
import com.badlogic.gdx.utils.XmlReader;
import com.badlogic.gdx.utils.XmlReader.Element;

/**
 * 
 * <body><b>PolygonSet</b> is class for constructing badlogic polygons from a
 * development tool.</body>
 * <ul>
 * <li><b>How to Use:</b></li>
 * <li>The constructor takes a path <i>(libGDX:
 * com.badlogic.gdx.files.FileHandle)</i> to the file made with the development
 * tool</li>
 * <li>You can then access your polygons by the name given to them via
 * development tool</li>
 * <li><i>*Note*</i> that you might want to perform a <b>deep clone</b> of each
 * polygon that gets returned if you want to use these polygons as templates for
 * multiple things in your application</li>
 * </ul>
 * <h1>Example:</h1> <br>
 * {@code PolygonSet p = new PolygonSet("/file.ypb");} <br>
 * {@code Polygon myPoly = p.find("shape-1");} <br>
 * <br>
 * 
 * @author Teddy Clapp
 */
public class PolygonSet {

	private Map<String, Polygon> map = new HashMap<>();

	public PolygonSet(FileHandle handle) {
		XmlReader reader = new XmlReader();
		Element polygon_set = reader.parse(handle);

		Array<Element> polygons = polygon_set.getChildrenByName("polygon");
		for (Element poly : polygons) {
			Polygon polygon = new Polygon();
			String[] origin = poly.getAttribute("origin").replaceAll("[()]", "").split(",");
			int originX = Integer.parseInt(origin[0]);
			int originY = Integer.parseInt(origin[1]);
			polygon.setOrigin(originX, originY);
			Element point = poly.getChildByName("points");
			Array<Element> points = point.getChildrenByName("point");
			float[] vertices = new float[points.size * 2];
			int index = 0;
			for (Element p : points) {
				String[] point_str = p.getText().replaceAll("[()]", "").split(",");
				int pX = Integer.parseInt(point_str[0]);
				int pY = Integer.parseInt(point_str[1]);
				vertices[index++] = pX;
				vertices[index++] = pY;
			}
			polygon.setVertices(vertices);
			map.put(poly.getAttributes().get("name"), polygon);
		}
	}

	public Polygon search(String key) {
		return map.get(key);
	}

	public Collection<Polygon> getValues() {
		return map.values();
	}
	
	public Collection<String> getKeys() {
		return map.keySet();
	}
}
