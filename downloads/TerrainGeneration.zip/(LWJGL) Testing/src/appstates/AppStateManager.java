package appstates;

public class AppStateManager {

	private AppState appstate;

	public AppState getAppstate() {
		return appstate;
	}

	public void setAppstate(AppState appstate) {
		this.appstate = appstate;
	}

}
