package appstates;

import java.util.ArrayList;
import java.util.List;

import org.lwjgl.input.Keyboard;
import org.lwjgl.util.vector.Vector3f;

import gos.Bunny;
import gos.GameObject;
import lights.Light;
import models.Loader;
import models.ModelTexture;
import renderers.Camera;
import renderers.MasterRenderer;
import terrains.Terrain;
import terrains.TerrainManager;
import utils.ProjectionMatrix;
import water.WaterRenderer;
import water.WaterShader;
import water.WaterTile;

public class PlayState extends AppState {

	private Camera camera = new Camera();
	private Light light = new Light(new Vector3f(Terrain.SIZE, 1500, Terrain.SIZE), new Vector3f(1, 1, 1));
	private MasterRenderer renderer = new MasterRenderer();

	private List<GameObject> gos = new ArrayList<>();
	private TerrainManager tm = new TerrainManager(Loader.getInstance());

	// water code
	private WaterShader ws = new WaterShader();
	private WaterRenderer wr = new WaterRenderer(ws, ProjectionMatrix.getInstance().getProjectionMatrix());
	List<WaterTile> waters = new ArrayList<>();

	public PlayState() {
		waters.add(new WaterTile(0, 0, -Terrain.MAX_HEIGHT / 4));

		for (int x = -1; x < 1; x++) {
			for (int z = -1; z < 1; z++) {
				Terrain terrain = new Terrain(x, z, Loader.getInstance(), new ModelTexture(Loader.getInstance().loadTexture("res/textures/mud.png")));
				tm.appendTerrain(terrain);
			}
		}

		// add bunnies
		for (int i = 0; i < 15; i++) {
			gos.add(new Bunny(tm, i * 25, 2300 + i * 25));
		}
	}

	@Override
	public void render(float dt) {

		// TOGGLE FOV
		if (Keyboard.isKeyDown(Keyboard.KEY_ADD)) {
			if (Keyboard.isKeyDown(Keyboard.KEY_NUMPAD0))
				ProjectionMatrix.getInstance().changeFOV(-0.25f);
			if (Keyboard.isKeyDown(Keyboard.KEY_NUMPAD1))
				ProjectionMatrix.getInstance().changeFOV(0.3f);
			renderer.updateProjectionMatrix();
			System.out.println("FOV: " + ProjectionMatrix.getInstance().getFOV());
		}

		tm.update(camera.getPosition());
		camera.move(tm.getCurrentTerrain(camera.getPosition()));

		int rad = 3;
		for (int i = 0; i < (rad * 2 + 1) * (rad * 2 + 1); i++) {
			renderer.processTerrain(tm.getNearblyTerrains(rad).get(i));
		}
		for (GameObject gameObject : gos) {
			gameObject.update();
			renderer.processGO(gameObject);
		}
		renderer.render(light, camera);
		wr.render(waters, camera);
	}

	@Override
	public void cleanUp() {
		// clean up
		renderer.cleanUp();
		ws.cleanUp();
		Loader.getInstance().cleanUp();
	}

}
