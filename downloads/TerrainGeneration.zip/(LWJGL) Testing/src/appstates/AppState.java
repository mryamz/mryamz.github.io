package appstates;

public abstract class AppState {
	
	public abstract void render(float dt);
	
	public abstract void cleanUp();

}
