package main;

import org.lwjgl.LWJGLException;
import org.lwjgl.Sys;
import org.lwjgl.input.Keyboard;
import org.lwjgl.opengl.ContextAttribs;
import org.lwjgl.opengl.Display;
import org.lwjgl.opengl.DisplayMode;
import org.lwjgl.opengl.PixelFormat;

import appstates.AppStateManager;
import appstates.PlayState;

public class AppLoop {

	private static long lastFrameTime;
	private static float delta;

	public static void main(String[] args) {

		// setup OpenGL's context
		ContextAttribs attribs = new ContextAttribs(3, 2).withForwardCompatible(true).withProfileCompatibility(true);
		try {
			// create renderable display
			Display.setDisplayMode(new DisplayMode(1280, 720));
			Display.create(new PixelFormat(), attribs);
		} catch (LWJGLException e) {
			e.printStackTrace();
		}
		lastFrameTime = getCurrentTime();

		AppStateManager asm = new AppStateManager();
		asm.setAppstate(new PlayState());

		while (!Display.isCloseRequested()) {
			asm.getAppstate().render(0);
			Display.sync(60);
			Display.update();
			long currentFrameTime = getCurrentTime();
			delta = (currentFrameTime - lastFrameTime) / 1000f;
			lastFrameTime = currentFrameTime;
			if (Keyboard.isKeyDown(Keyboard.KEY_ESCAPE)) {
				break;
			}
		}
		asm.getAppstate().cleanUp();
		Display.destroy();
	}

	public static float getFrameTimeSeconds() {
		return delta;
	}

	private static long getCurrentTime() {
		return Sys.getTime() * 1000 / Sys.getTimerResolution();
	}
}
