package gos;

import java.util.ArrayList;

import java.util.List;

import org.lwjgl.util.vector.Vector3f;

import components.Component;
import components.RenderComponent;
import components.TransformComponent;
import models.Loader;
import models.ModelTexture;
import models.TexturedModel;
import parsers.OBJParser;

/**
 * This creates a basic game object where the two default components are
 * TransformComonent and RenderComponent.
 * 
 * @author mryamz
 * @since 2/4/2017
 * 
 * 
 */

public abstract class GameObject {

	protected List<Component> components = new ArrayList<>();

	public GameObject() {
		Vector3f v3f = new Vector3f();
		components.add(new TransformComponent(this, v3f, 0, 0, 0, 1));
		components.add(new RenderComponent(new TexturedModel(OBJParser.loadObjModel("res/objs/default.obj"), new ModelTexture(Loader.getInstance().loadTexture("res/textures/white.png")))));
	}

	public GameObject(float x, float y, float z, float rx, float ry, float rz, float scale, String pathToOBJMesh, String pathToPNGTexture) {
		Vector3f v3f = new Vector3f(x, y, z);
		components.add(new TransformComponent(this, v3f, rx, ry, rz, scale));
		components.add(new RenderComponent(new TexturedModel(OBJParser.loadObjModel(pathToOBJMesh), new ModelTexture(Loader.getInstance().loadTexture(pathToPNGTexture)))));
	}
	
	public abstract String getName();

	public void update() {
		for (Component component : components) {
			component.update();
		}
	}

	public Component findComponent(int type) {
		for (Component component : components) {
			if (component.getType() == type) {
				return component;
			}
		}
		
		throw new RuntimeException("Cannot find specifed component :/ You must add component type: " + type + " to the GameObject's list before searching for it :)");
	}

	public void addComponent(Component... components) {
		for (Component c : components) {
			this.components.add(c);
		}
	}

	public void addRemove(Component... components) {
		for (Component c : components) {
			this.components.remove(c);
		}
	}
}
