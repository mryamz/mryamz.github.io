package gos;

import components.AutoMoveComponent;
import components.GravityComponent;
import components.TerrainCollisionComponent;
import terrains.TerrainManager;

public class Bunny extends GameObject {
	
	public Bunny(TerrainManager tm, float x, float z) {
		super(x, 0, z, 0, 0, 0, 3, "res/objs/bunny.obj", "res/textures/white.png");
		
		addComponent(new GravityComponent(this),  new AutoMoveComponent(this), new TerrainCollisionComponent(this, tm));
	}

	@Override
	public String getName() {
		return "bunny";
	}

}
