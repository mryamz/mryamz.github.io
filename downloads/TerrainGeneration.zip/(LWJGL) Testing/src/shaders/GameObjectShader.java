package shaders;

import org.lwjgl.opengl.GL20;
import org.lwjgl.util.vector.Matrix4f;

import lights.Light;
import renderers.Camera;
import utils.Utils;

public class GameObjectShader extends ShaderProgram {
	
	private int location_transformationMatrix;
	private int location_projectionMatrix;
	private int location_viewMatrix;

	private int location_lightPosition;
	private int location_lightColor;

	
	public GameObjectShader() {
		super("src/shaders/gameobject_shader.vert", "src/shaders/gameobject_shader.frag");
	}

	@Override
	protected void bindAttributes() {
		super.bindAttribute(0, "position");
		super.bindAttribute(1, "textureCoords");
		super.bindAttribute(2, "normal");
	}

	@Override
	protected void getAllUniformLocations() {
		location_transformationMatrix = super.getUniformLocation("transformationMatrix");
		location_projectionMatrix = super.getUniformLocation("projectionMatrix");
		location_viewMatrix = super.getUniformLocation("viewMatrix");
		
		location_lightPosition = super.getUniformLocation("lightPosition");
		location_lightColor = super.getUniformLocation("lightColor");
	}
	
	public void loadLight(Light light) {
		GL20.glUniform3f(location_lightPosition, light.getPosition().x, light.getPosition().y, light.getPosition().z);
		GL20.glUniform3f(location_lightColor, light.getColor().x, light.getColor().y, light.getColor().z);
	}

	public void loadTransformationMatrix(Matrix4f matrix) {
		super.loadMatrix(location_transformationMatrix, matrix);
	}
	
	public void loadProjectionMatrix(Matrix4f matrix) {
		super.loadMatrix(location_projectionMatrix, matrix);
	}
	
	public void loadViewMatrix(Camera cam) {
		Matrix4f vm = Utils.createViewMatrix(cam);
		super.loadMatrix(location_viewMatrix, vm);
	}
}
