package shaders;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.nio.FloatBuffer;

import org.lwjgl.BufferUtils;
import org.lwjgl.opengl.GL20;
import org.lwjgl.util.vector.Matrix4f;

/**
 * 
 * Represent generic shader program that all shader programs will need.
 *
 */

public abstract class ShaderProgram {

	private int programID;
	private int vertexShaderID;
	private int fragmentShaderID;
	
	private static FloatBuffer matrixBuffer = BufferUtils.createFloatBuffer(16);

	public ShaderProgram(String vertexFile, String fragmentFile) {
		vertexShaderID = loadShader(vertexFile, GL20.GL_VERTEX_SHADER);
		fragmentShaderID = loadShader(fragmentFile, GL20.GL_FRAGMENT_SHADER);
		System.out.println();
		programID = GL20.glCreateProgram();
		GL20.glAttachShader(programID, vertexShaderID);
		GL20.glAttachShader(programID, fragmentShaderID);
		bindAttributes();
		GL20.glLinkProgram(programID);
		GL20.glValidateProgram(programID);
		getAllUniformLocations();
	}

	public void start() {
		GL20.glUseProgram(programID);
	}

	public void stop() {
		GL20.glUseProgram(0);
	}

	public void cleanUp() {
		stop();
		GL20.glDetachShader(programID, vertexShaderID);
		GL20.glDetachShader(programID, fragmentShaderID);
		GL20.glDeleteShader(vertexShaderID);
		GL20.glDeleteShader(fragmentShaderID);
		GL20.glDeleteProgram(programID);
	}

	protected abstract void bindAttributes();

	/**
	 * - Load an attribute from the bounded VAO as an input to a shader program.
	 * - Grab input from bounded VAO
	 */
	protected void bindAttribute(int attributeIndex, String name) {
		GL20.glBindAttribLocation(programID, attributeIndex, name);
	}

	/**
	 * get the location of a uniform variable in shader code
	 */
	protected abstract void getAllUniformLocations();

	protected int getUniformLocation(String name) {
		return GL20.glGetUniformLocation(programID, name);
	}
	
	protected void loadMatrix(int loc, Matrix4f matrix) {
		matrix.store(matrixBuffer);
		matrixBuffer.flip();
		GL20.glUniformMatrix4(loc, false, matrixBuffer);
	}
	
	protected void loadFloat(int loc, float value) {
		GL20.glUniform1f(loc, value);
	}
	
	public static int loadShader(String file, int type) {
		StringBuilder src = new StringBuilder();

		try {
			BufferedReader reader = new BufferedReader(new FileReader(new File(file)));

			while (reader.ready()) {
				src.append(reader.readLine()).append("\n");
			}
			reader.close();
		} catch (Exception e) {
			e.printStackTrace();
		}

		int shaderID = GL20.glCreateShader(type);
		GL20.glShaderSource(shaderID, src);
		GL20.glCompileShader(shaderID);
		System.out.println(file + ": " + (GL20.glGetShaderInfoLog(shaderID, 500).length() == 0 ? "Compiled Sucessful" : GL20.glGetShaderInfoLog(shaderID, 500)));
		return shaderID;
	}
}
