package utils;

import java.awt.Point;
import java.util.Random;

public class SimplixNoise2DOctave {

	private int numberOfSwaps = 400;

	private final double F2 = 0.5 * (Math.sqrt(3.0) - 1.0);
	private final double G2 = (3.0 - Math.sqrt(3)) / 6;

	private Point[] points = { new Point(1, 1), new Point(-1, 1), new Point(1, -1), new Point(-1, -1) };

	private static short[] p_supply = { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 133, 134, 135, 136, 137, 138, 139, 140, 141, 142, 143, 144, 145, 146,
			147, 148, 149, 150, 151, 152, 153, 154, 155, 156, 157, 158, 159, 160, 161, 162, 163, 164, 165, 166, 167, 168, 169, 170, 171, 172, 173, 174, 175, 176, 177, 178, 179, 180, 181, 182, 183, 184, 185, 186, 187, 188, 189, 190, 191, 192, 193, 194, 195, 196, 197, 198, 199, 200, 201, 202, 203, 204, 205, 206, 207, 208, 209, 210, 211, 212, 213, 214, 215, 216, 217, 218, 219, 220, 221, 222, 223, 224, 225, 226, 227, 228, 229, 230, 231, 232, 233, 234, 235, 236, 237, 238, 239, 240, 241, 242, 243, 244, 245, 246, 247, 248, 249, 250, 251, 252, 253, 254, 255 };

	private short p[];

	private short perm[] = new short[512];
	private short permMod12[] = new short[512];

	public SimplixNoise2DOctave(int seed) {
		p = p_supply.clone();
		Random random = new Random(seed);

		for (int i = 0; i < numberOfSwaps; i++) {
			int from = random.nextInt(p.length);
			int to = random.nextInt(p.length);
			short temp_p = p[from];
			p[from] = p[to];
			p[to] = temp_p;
		}
		for (int i = 0; i < perm.length; i++) {

			perm[i] = p[i & 255];
			permMod12[i] = (short) (perm[i] % 4);
		}
	}

	private int fastFloor(double x) {
		int xi = (int) x;
		return x < xi ? xi - 1 : xi;
	}

	private double dot(Point point, double x, double y) {
		return point.x * x + point.y * y;
	}

	public double noise(double xin, double yin) {
		double n0, n1, n2;
		double s = (xin + yin) * F2;
		int i = fastFloor(xin + s);
		int j = fastFloor(yin + s);
		double t = (i + j) * G2;
		double X0 = i - t;
		double Y0 = j - t;
		double x0 = xin - X0;
		double y0 = yin - Y0;

		int i1, j1;
		if (x0 > y0) {
			i1 = 1;
			j1 = 0;
		} else {
			i1 = 0;
			j1 = 1;
		}
		double x1 = x0 - i1 + G2;
		double y1 = y0 - j1 + G2;
		double x2 = x0 - 1.0 + 2.0 * G2;
		double y2 = y0 - 1.0 + 2.0 * G2;

		int ii = i & 255;
		int jj = j & 255;

		int gi0 = permMod12[ii + perm[jj]];
		int gi1 = permMod12[ii + i1 + perm[jj + j1]];
		int gi2 = permMod12[ii + 1 + perm[jj + 1]];

		double t0 = 0.5 - x0 * x0 - y0 * y0;
		if (t0 < 0) {
			n0 = 0;
		} else {
			t0 *= t0;
			n0 = t0 * t0 * dot(points[gi0], x0, y0);
		}

		double t1 = 0.5 - x1 * x1 - y1 * y1;
		if (t1 < 0) {
			n1 = 0;
		} else {
			t1 *= t1;
			n1 = t1 * t1 * dot(points[gi1], x1, y1);
		}

		double t2 = 0.5 - x2 * x2 - y2 * y2;
		if (t2 < 0) {
			n2 = 0;
		} else {
			t2 *= t2;
			n2 = t2 * t2 * dot(points[gi2], x2, y2);
		}

		return 70 * (n0 + n1 + n2);
	}
}
