package utils;

import org.lwjgl.opengl.Display;
import org.lwjgl.util.vector.Matrix4f;

public class ProjectionMatrix {

	private final float FOV = 75;
	private float fov = FOV;
	private final float NEAR_PLANE = 0.01f;
	private final float FAR_PLANE = Integer.MAX_VALUE;

	private Matrix4f projMat = new Matrix4f();

	private static ProjectionMatrix projectionMatrix;

	private ProjectionMatrix() {
	}

	public static ProjectionMatrix getInstance() {
		if (projectionMatrix == null) {
			projectionMatrix = new ProjectionMatrix();
		}

		return projectionMatrix;
	}

	public void initProjectionMatrix() {
		float aspectRatio = (float) Display.getWidth() / (float) Display.getHeight();
		float y_scale = (float) ((1f / Math.tan(Math.toRadians(FOV / 2f))) * aspectRatio);
		float x_scale = y_scale / aspectRatio;
		float frustum_length = FAR_PLANE - NEAR_PLANE;

		projMat.m00 = x_scale;
		projMat.m11 = y_scale;
		projMat.m22 = -((FAR_PLANE + NEAR_PLANE) / frustum_length);
		projMat.m23 = -1;
		projMat.m32 = -((2 * NEAR_PLANE * FAR_PLANE) / frustum_length);
	}

	public void updateProjectionMatrix() {
		float aspectRatio = (float) Display.getWidth() / (float) Display.getHeight();
		float y_scale = (float) ((1f / Math.tan(Math.toRadians(fov / 2f))) * aspectRatio);
		float x_scale = y_scale / aspectRatio;
		float frustum_length = FAR_PLANE - NEAR_PLANE;

		projMat.m00 = x_scale;
		projMat.m11 = y_scale;
		projMat.m22 = -((FAR_PLANE + NEAR_PLANE) / frustum_length);
		projMat.m23 = -1;
		projMat.m32 = -((2 * NEAR_PLANE * FAR_PLANE) / frustum_length);
	}

	public void changeFOV(float amtD) {
		fov += amtD;
		if (fov < 0.1) {
			fov = 0.1f;
		}
		if (fov > 90) {
			fov = 90;
		}
	}
	
	public float getFOV() {
		return fov;
	}

	public Matrix4f getProjectionMatrix() {
		return projMat;
	}
}
