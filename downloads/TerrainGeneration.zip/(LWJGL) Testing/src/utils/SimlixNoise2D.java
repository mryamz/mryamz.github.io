package utils;


public class SimlixNoise2D {

	private SimplixNoise2DOctave[] ocataves;

	private double[] frequencies;
	private double[] amplitudes;

	public SimlixNoise2D(int numberOfOctaves, double persistance) {
		ocataves = new SimplixNoise2DOctave[numberOfOctaves];
		frequencies = new double[numberOfOctaves];
		amplitudes = new double[numberOfOctaves];

		for (int i = 0; i < numberOfOctaves; i++) {
			ocataves[i] = new SimplixNoise2DOctave(Utils.SEED);
			frequencies[i] = Math.pow(2, i);
			amplitudes[i] = Math.pow(persistance, ocataves.length - i);
		}
	}

	public double getNoise(int x, int y) {
		double result = 0;

		for (int i = 0; i < ocataves.length; i++) {
			result += ocataves[i].noise(x / frequencies[i], y / frequencies[i]) * amplitudes[i];
		}
		return result;
	}

}
