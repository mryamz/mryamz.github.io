package components;

import org.lwjgl.util.vector.Vector3f;

import gos.GameObject;

public class TransformComponent implements Component {

	private Vector3f position;
	private float rx, ry, rz;
	private float scale;
	
	private GameObject holder;

	public TransformComponent(GameObject holder, Vector3f position, float rx, float ry, float rz, float scale) {
		this.holder = holder;
		this.position = position;
		this.rx = rx;
		this.ry = ry;
		this.rz = rz;
		this.scale = scale;
	}

	public void increaseRotation(float rdx, float rdy, float rdz) {
		this.rx += rdx;
		this.ry += rdy;
		this.rz += rdz;
	}
	
	public void increasePosition(float dx, float dy, float dz) {
		this.position.x += dx;
		this.position.y += dy;
		this.position.z += dz;
	}

	@Override
	public void update() {

	}

	@Override
	public int getType() {
		return Component.TYPE_TRANSFORM_COMPONENT;
	}

	public Vector3f getPosition() {
		return position;
	}

	public void setPosition(Vector3f position) {
		this.position = position;
	}

	public float getRx() {
		return rx;
	}

	public void setRx(float rx) {
		this.rx = rx;
	}

	public float getRy() {
		return ry;
	}

	public void setRy(float ry) {
		this.ry = ry;
	}

	public float getRz() {
		return rz;
	}

	public void setRz(float rz) {
		this.rz = rz;
	}

	public float getScale() {
		return scale;
	}

	public void setScale(float scale) {
		this.scale = scale;
	}

	@Override
	public GameObject getHolder() {
		return holder;
	}
}
