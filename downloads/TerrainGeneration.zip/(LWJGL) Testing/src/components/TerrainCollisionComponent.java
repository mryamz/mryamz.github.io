package components;

import org.lwjgl.util.vector.Vector3f;

import gos.GameObject;
import terrains.Terrain;
import terrains.TerrainManager;

public class TerrainCollisionComponent implements Component {

	private GameObject holder;
	private TerrainManager tm;

	public TerrainCollisionComponent(GameObject holder, TerrainManager tm) {
		this.holder = holder;
		this.tm = tm;
	}

	@Override
	public void update() {
		TransformComponent tc = (TransformComponent) holder.findComponent(Component.TYPE_TRANSFORM_COMPONENT);
		Vector3f position = tc.getPosition();
		Terrain t = getTerrain();
		if (t == null) {
			return;
		}
		float terrainHeight = t.getInterpolatedHeight(position.x, position.z);
		if (position.y < terrainHeight) {
			position.y = terrainHeight;
		}
	}

	public Terrain getTerrain() {
		TransformComponent tc = (TransformComponent) holder.findComponent(Component.TYPE_TRANSFORM_COMPONENT);
		return tm.getCurrentTerrain(tc.getPosition());
	}

	@Override
	public int getType() {
		return Component.TYPE_TERRAIN_COLLISION_COMPONENT;
	}

	@Override
	public GameObject getHolder() {
		return holder;
	}

}
