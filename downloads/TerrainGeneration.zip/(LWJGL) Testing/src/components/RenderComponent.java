package components;

import gos.GameObject;
import models.TexturedModel;

public class RenderComponent implements Component {

	private TexturedModel model;

	public RenderComponent(TexturedModel model) {
		this.model = model;
	}

	@Override
	public void update() {

	}

	@Override
	public int getType() {
		return Component.TYPE_RENDER_COMPONENT;
	}

	public TexturedModel getModel() {
		return model;
	}

	public void setModel(TexturedModel model) {
		this.model = model;
	}

	@Override
	public GameObject getHolder() {
		// TODO Auto-generated method stub
		return null;
	}
}
