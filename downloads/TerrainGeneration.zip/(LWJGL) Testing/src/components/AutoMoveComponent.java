package components;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Random;
import java.util.concurrent.ThreadLocalRandom;

import javax.swing.Timer;

import gos.GameObject;
import main.AppLoop;

public class AutoMoveComponent implements Component {

	private static final float RUN_SPEED = 65;
	private static final float TURN_SPEED = 95;

	private float currentSpeed = RUN_SPEED;
	private float currentTurnSpeed = TURN_SPEED;

	// shouldTurn=-1 -> no turn, shouldTurn=0 -> left turn, shouldTurn=1 ->
	// right turn
	private int shouldTurn;

	private GameObject holder;

	public AutoMoveComponent(GameObject holder) {
		this.holder = holder;

		new Timer(1000, new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				shouldTurn = new Random().nextInt(2) - 1;
				currentTurnSpeed = ThreadLocalRandom.current().nextInt(15, (int) TURN_SPEED);
			}
		}).start();
	}

	@Override
	public void update() {
		TransformComponent tc = (TransformComponent) holder.findComponent(Component.TYPE_TRANSFORM_COMPONENT);

		switch (shouldTurn) {
		case -1:
			tc.increaseRotation(0, 0, 0);
			break;
		case 0:
			tc.increaseRotation(0, -currentTurnSpeed * AppLoop.getFrameTimeSeconds(), 0);
			break;
		case 1:
			tc.increaseRotation(0, currentTurnSpeed * AppLoop.getFrameTimeSeconds(), 0);
			break;
		}

		float distance = currentSpeed * AppLoop.getFrameTimeSeconds();
		float dx = (float) (distance * Math.sin(Math.toRadians(tc.getRy())));
		float dz = (float) (distance * Math.cos(Math.toRadians(tc.getRy())));
		tc.increasePosition(dx, 0, dz);
	}

	@Override
	public int getType() {
		return TYPE_AUTO_MOVE_COMPONENT;
	}

	@Override
	public GameObject getHolder() {
		return holder;
	}

}
