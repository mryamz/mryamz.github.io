package components;

import gos.GameObject;
import main.AppLoop;

public class GravityComponent implements Component {
	
	private static final int MAX_GRAVITY = 3000;
	
	private float downForce = -15;
	private float currentDownForce = 15;
	
	private GameObject holder;
	
	public GravityComponent(GameObject holder) {
		this.holder = holder;
	}

	@Override
	public void update() {
		TransformComponent tc = (TransformComponent) holder.findComponent(Component.TYPE_TRANSFORM_COMPONENT);
		
		currentDownForce += downForce;
		
		if(currentDownForce < -MAX_GRAVITY) {
			currentDownForce = -MAX_GRAVITY;
		}
		
		tc.increasePosition(0, currentDownForce * AppLoop.getFrameTimeSeconds(), 0);
	}

	@Override
	public int getType() {
		return TYPE_GRAVITY_COMPONENT;
	}

	@Override
	public GameObject getHolder() {
		return holder;
	}

}
