package components;

import gos.GameObject;

public interface Component {

	public static final int TYPE_TRANSFORM_COMPONENT = 0;
	public static final int TYPE_RENDER_COMPONENT = 1;
	public static final int TYPE_AUTO_MOVE_COMPONENT = 2;
	public static final int  TYPE_TERRAIN_COLLISION_COMPONENT= 3;
	public static final int  TYPE_GRAVITY_COMPONENT= 4;

	void update();

	int getType();

	GameObject getHolder();

}
