package terrains;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

import org.lwjgl.util.vector.Vector3f;

import models.Loader;
import models.ModelTexture;

public class TerrainManager {

	private List<Terrain> terrains = new CopyOnWriteArrayList<>();
	
	public static final String PATH = "res/textures/grass.png";

	private int gridX;
	private int gridZ;

	private Loader loader;

	public TerrainManager(Loader loader) {
		this.loader = loader;
	}

	public void update(Vector3f position) {
		gridX = (int) Math.floor(position.x / Terrain.SIZE);
		gridZ = (int) Math.floor(position.z / Terrain.SIZE);

		int bufferAmt = 6;
		addNearby(gridX, gridZ, bufferAmt);

		List<Terrain> keeps = getNearblyTerrains(bufferAmt);
		for (Terrain terrain : terrains) {
			if (!keeps.contains(terrain)) {
				terrains.remove(terrain);
			}
		}
	}
	

	public List<Terrain> getNearblyTerrains(int radius) {
		List<Terrain> near_terrains = new ArrayList<>();
		for (int x = -radius; x < radius; x++) {
			for (int z = -radius; z < radius; z++) {
				// add center
				if (hasTerrain(gridX, gridZ) && !near_terrains.contains(getCurrentTerrain(gridX, gridZ))) {
					near_terrains.add(getCurrentTerrain(gridX, gridZ));
				}

				// add down
				if (hasTerrain(gridX, gridZ + z) && !near_terrains.contains(getCurrentTerrain(gridX, gridZ + z))) {
					near_terrains.add(getCurrentTerrain(gridX, gridZ + z));
				}

				// add up
				if (hasTerrain(gridX, gridZ - z) && !near_terrains.contains(getCurrentTerrain(gridX, gridZ - z))) {
					near_terrains.add(getCurrentTerrain(gridX, gridZ - z));
				}

				// add left
				if (hasTerrain(gridX + x, gridZ) && !near_terrains.contains(getCurrentTerrain(gridX + x, gridZ))) {
					near_terrains.add(getCurrentTerrain(gridX + x, gridZ));
				}

				// add right
				if (hasTerrain(gridX - x, gridZ) && !near_terrains.contains(getCurrentTerrain(gridX - x, gridZ))) {
					near_terrains.add(getCurrentTerrain(gridX - x, gridZ));
				}

				// add diagonal
				if (hasTerrain(gridX + x, gridZ + z) && !near_terrains.contains(getCurrentTerrain(gridX + x, gridZ + z))) {
					near_terrains.add(getCurrentTerrain(gridX + x, gridZ + z));
				}

				// add diagonal
				if (hasTerrain(gridX - x, gridZ - z) && !near_terrains.contains(getCurrentTerrain(gridX - x, gridZ - z))) {
					near_terrains.add(getCurrentTerrain(gridX - x, gridZ - z));
				}

				// add diagonal
				if (hasTerrain(gridX + x, gridZ - z) && !near_terrains.contains(getCurrentTerrain(gridX + x, gridZ - z))) {
					near_terrains.add(getCurrentTerrain(gridX + x, gridZ - z));
				}

				// add diagonal
				if (hasTerrain(gridX - x, gridZ + z) && !near_terrains.contains(getCurrentTerrain(gridX - x, gridZ + z))) {
					near_terrains.add(getCurrentTerrain(gridX - x, gridZ + z));
				}
			}
		}
		return near_terrains;
	}

	public void addNearby(int gridX, int gridZ, int radius) {
		for (int x = -radius; x < radius; x++) {
			for (int z = -radius; z < radius; z++) {
				// add down
				if (!hasTerrain(gridX, gridZ + z)) {
					appendTerrain(new Terrain(gridX, gridZ + z, loader, new ModelTexture(loader.loadTexture(PATH))));
				}

				// add up
				if (!hasTerrain(gridX, gridZ - z)) {
					appendTerrain(new Terrain(gridX, gridZ - z, loader, new ModelTexture(loader.loadTexture(PATH))));
				}

				// add left
				if (!hasTerrain(gridX + x, gridZ)) {
					appendTerrain(new Terrain(gridX + x, gridZ, loader, new ModelTexture(loader.loadTexture(PATH))));
				}

				// add right
				if (!hasTerrain(gridX - x, gridZ)) {
					appendTerrain(new Terrain(gridX - x, gridZ, loader, new ModelTexture(loader.loadTexture(PATH))));
				}

				// add diagonal
				if (!hasTerrain(gridX + x, gridZ + z)) {
					appendTerrain(new Terrain(gridX + x, gridZ + z, loader, new ModelTexture(loader.loadTexture(PATH))));
				}

				// add diagonal
				if (!hasTerrain(gridX - x, gridZ - z)) {
					appendTerrain(new Terrain(gridX - x, gridZ - z, loader, new ModelTexture(loader.loadTexture(PATH))));
				}

				// add diagonal
				if (!hasTerrain(gridX + x, gridZ - z)) {
					appendTerrain(new Terrain(gridX + x, gridZ - z, loader, new ModelTexture(loader.loadTexture(PATH))));
				}

				// add diagonal
				if (!hasTerrain(gridX - x, gridZ + z)) {
					appendTerrain(new Terrain(gridX - x, gridZ + z, loader, new ModelTexture(loader.loadTexture(PATH))));
				}
			}
		}
	}

	public void removeTerrain(int gridX, int gridZ) {
		for (Terrain terrain : terrains) {
			if (terrain.getGridX() == gridX && terrain.getGridZ() == gridZ) {
				terrains.remove(terrain);
			}
		}
	}

	public void appendTerrain(Terrain t) {
		terrains.add(t);
	}

	public List<Terrain> getTerrain() {
		return terrains;
	}

	public boolean hasTerrain(int gridX, int gridZ) {
		for (Terrain terrain : terrains) {
			if (terrain.getGridX() == gridX && terrain.getGridZ() == gridZ) {
				return true;
			}
		}
		return false;
	}

	public Terrain getCurrentTerrain(Vector3f position) {
		int locGridX = (int) Math.floor(position.x / Terrain.SIZE);
		int locGridZ = (int) Math.floor(position.z / Terrain.SIZE);

		for (Terrain terrain : terrains) {
			if (terrain.getGridX() == locGridX && terrain.getGridZ() == locGridZ) {
				return terrain;
			}
		}

		return null;
	}

	public Terrain getCurrentTerrain(int gx, int gz) {
		for (Terrain terrain : terrains) {
			if (terrain.getGridX() == gx && terrain.getGridZ() == gz) {
				return terrain;
			}
		}

		return null;
	}
}
