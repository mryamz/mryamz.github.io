package terrains;

import org.lwjgl.util.vector.Vector2f;
import org.lwjgl.util.vector.Vector3f;

import models.Loader;
import models.ModelTexture;
import models.RawModel;
import utils.SimlixNoise2D;
import utils.Utils;

public class Terrain {

	private static final int HEIGHT_SCALE = 8;
	
	public static final float SIZE = 1000 * 2;
	public static final float MAX_HEIGHT = 375 * HEIGHT_SCALE;
	public static final int VERTEX_COUNT = 128 / (HEIGHT_SCALE / 2);

	private float x;
	private float z;
	private RawModel model;
	private ModelTexture texture;

	private float[][] heights = new float[VERTEX_COUNT][VERTEX_COUNT];

	private SimlixNoise2D noise = new SimlixNoise2D(8, .375);
	private int noiseX, noiseZ;

	private int gridX, gridZ;

	public Terrain(int gridX, int gridZ, Loader loader, ModelTexture texture) {
		this.texture = texture;
		this.gridX = gridX;
		this.gridZ = gridZ;
		this.x = gridX * SIZE;
		this.z = gridZ * SIZE;
		noiseX = (int) (gridX * (VERTEX_COUNT - 1));
		noiseZ = (int) (gridZ * (VERTEX_COUNT - 1));
		this.model = generateTerrain(loader);
	}
	
	private RawModel generateTerrain(Loader loader) {
		int count = VERTEX_COUNT * VERTEX_COUNT;
		float[] vertices = new float[count * 3];
		float[] normals = new float[count * 3];
		float[] textureCoords = new float[count * 2];
		int[] indices = new int[6 * (VERTEX_COUNT - 1) * (VERTEX_COUNT - 1)];

		int vertexPointer = 0;
		for (int i = 0; i < VERTEX_COUNT; i++) {
			for (int j = 0; j < VERTEX_COUNT; j++) {
				// set vertex positions
				float height = getHeight(i + noiseZ, j + noiseX);
				heights[j][i] = height;
				vertices[vertexPointer * 3] = (float) j / ((float) VERTEX_COUNT - 1) * SIZE;
				vertices[vertexPointer * 3 + 1] = height;
				vertices[vertexPointer * 3 + 2] = (float) i / ((float) VERTEX_COUNT - 1) * SIZE;

				// set normals (done incorrectly) TODO
				Vector3f normal = getNormal(i, j);
				normals[vertexPointer * 3] = normal.x;
				normals[vertexPointer * 3 + 1] = normal.y;
				normals[vertexPointer * 3 + 2] = normal.z;

				// set UVs 1 to 1 with vertices at i and j respectively
				textureCoords[vertexPointer * 2] = (float) j / ((float) VERTEX_COUNT - 1);
				textureCoords[vertexPointer * 2 + 1] = (float) i / ((float) VERTEX_COUNT - 1);
				vertexPointer++;
			}
		}

		// index for setting indices
		int pointer = 0;
		for (int gz = 0; gz < VERTEX_COUNT - 1; gz++) {
			for (int gx = 0; gx < VERTEX_COUNT - 1; gx++) {

				// gather the corners of the quad
				int topLeft = (gz * VERTEX_COUNT) + gx;
				int topRight = topLeft + 1;
				int bottomLeft = ((gz + 1) * VERTEX_COUNT) + gx;
				int bottomRight = bottomLeft + 1;

				// connect each corner in a triangled fashion
				indices[pointer++] = topLeft;
				indices[pointer++] = bottomLeft;
				indices[pointer++] = topRight;
				indices[pointer++] = topRight;
				indices[pointer++] = bottomLeft;
				indices[pointer++] = bottomRight;
			}
		}

		// load generated data into VAO
		return loader.loadToVAO(vertices, textureCoords, normals, indices);
	}

	public float getInterpolatedHeight(float worldX, float worldZ) {
		float terrainX = worldX - this.x;
		float terrainZ = worldZ - this.z;
		float gridSquareSize = SIZE / ((float) heights.length - 1);
		int gridX = (int) Math.floor(terrainX / gridSquareSize);
		int gridZ = (int) Math.floor(terrainZ / gridSquareSize);
		if (gridX >= heights.length - 1 || gridZ >= heights.length - 1 || gridX < 0 || gridZ < 0) {
			return -MAX_HEIGHT;
		}
		float xCoord = (terrainX % gridSquareSize) / gridSquareSize;
		float zCoord = (terrainZ % gridSquareSize) / gridSquareSize;
		float answer;
		if (xCoord <= (1 - zCoord)) {
			answer = Utils.barryCentric(new Vector3f(0, heights[gridX][gridZ], 0), new Vector3f(1, heights[gridX + 1][gridZ], 0), new Vector3f(0, heights[gridX][gridZ + 1], 1), new Vector2f(xCoord, zCoord));
		} else {
			answer = Utils.barryCentric(new Vector3f(1, heights[gridX + 1][gridZ], 0), new Vector3f(1, heights[gridX + 1][gridZ + 1], 1), new Vector3f(0, heights[gridX][gridZ + 1], 1), new Vector2f(xCoord, zCoord));
		}
		return answer;
	}

	public Vector3f getNormal(int x, int z) {
		float heightL = getHeightForNormal(x - 1, z);
		float heightR = getHeightForNormal(x + 1, z);
		float heightD = getHeightForNormal(x, z - 1);
		float heightU = getHeightForNormal(x, z + 1);

		Vector3f normal = new Vector3f(heightL - heightR, 2f, heightD - heightU);
		normal.normalise();
		return normal;
	}

	private float getHeightForNormal(int x, int z) {
		float height = (float) noise.getNoise(x + noiseZ, z + noiseX);
		return height * MAX_HEIGHT;
	}

	private float getHeight(int x, int z) {
		float height = (float) noise.getNoise(x, z);
		return height * MAX_HEIGHT;
	}

	public float getX() {
		return x;
	}

	public float getZ() {
		return z;
	}

	public RawModel getModel() {
		return model;
	}

	public ModelTexture getTexture() {
		return texture;
	}

	public int getGridX() {
		return gridX;
	}

	public int getGridZ() {
		return gridZ;
	}

}
