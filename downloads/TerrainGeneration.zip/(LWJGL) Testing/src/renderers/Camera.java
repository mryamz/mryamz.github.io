package renderers;

import org.lwjgl.input.Keyboard;
import org.lwjgl.input.Mouse;
import org.lwjgl.util.vector.Vector3f;

import terrains.Terrain;

public class Camera {

	private Vector3f position = new Vector3f(-2769.9192f, 180.00008f, 1076.0607f);
	private Vector3f direction = new Vector3f();
	private float speed = 2.6f;

	private float pitch = 30;
	private float yaw = 120;
	private float roll;

	private boolean testTerrain;

	public void move(Terrain t) {
		if (Keyboard.isKeyDown(Keyboard.KEY_END)) {
			testTerrain = false;
		}
		if (Keyboard.isKeyDown(Keyboard.KEY_HOME)) {
			testTerrain = true;
		}

		if (testTerrain && t != null) {
			position.y = t.getInterpolatedHeight(position.x, position.z) + 25;
		}

		speed += (Mouse.getDWheel() / 1200f);
		if (speed < 0.1f) {
			speed = 0.1f;
		}

		direction.x = (float) (speed * Math.sin(Math.toRadians(yaw)));
		direction.z = (float) (speed * Math.cos(Math.toRadians(yaw)));

		if (Keyboard.isKeyDown(Keyboard.KEY_W)) {
			position.x += direction.x;
			position.z -= direction.z;
		}

		if (Keyboard.isKeyDown(Keyboard.KEY_S)) {
			position.x -= direction.x;
			position.z += direction.z;
		}

		if (Keyboard.isKeyDown(Keyboard.KEY_R)) {
			position.y += speed;
		}

		if (Keyboard.isKeyDown(Keyboard.KEY_F)) {
			position.y -= speed;
		}

		if (Mouse.isButtonDown(0)) {
			yaw += Mouse.getDX() / 3.25f;
			pitch += Mouse.getDY() / 3.25f;
		}
	}

	public Vector3f getPosition() {
		return position;
	}

	public float getPitch() {
		return pitch;
	}

	public float getYaw() {
		return yaw;
	}

	public float getRoll() {
		return roll;
	}
}
