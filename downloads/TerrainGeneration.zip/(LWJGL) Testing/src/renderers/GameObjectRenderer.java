package renderers;

import java.util.List;
import java.util.Map;

import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL13;
import org.lwjgl.opengl.GL20;
import org.lwjgl.opengl.GL30;
import org.lwjgl.util.vector.Matrix4f;

import components.Component;
import components.RenderComponent;
import components.TransformComponent;
import gos.GameObject;
import models.TexturedModel;
import shaders.GameObjectShader;
import utils.Utils;

/**
 * - Renders a RawModel from a VAO
 *
 */

public class GameObjectRenderer {

	private GameObjectShader shader;

	public GameObjectRenderer(GameObjectShader shader) {
		this.shader = shader;
	}

	/**
	 * - called once per frame - prepares openGL to render a scene
	 */
	public void prepare() {
		GL11.glEnable(GL11.GL_DEPTH_TEST);
		GL11.glClearColor(22f / 255f, 166f / 255f, 1, 1);
		GL11.glClear(GL11.GL_COLOR_BUFFER_BIT | GL11.GL_DEPTH_BUFFER_BIT);
	}

	public void render(Map<TexturedModel, List<GameObject>> gos) {
		for (TexturedModel model : gos.keySet()) {
			prepareTexturedModel(model);
			List<GameObject> batch = gos.get(model);
			for (GameObject go : batch) {
				prepareInstance(go);
				GL11.glDrawElements(GL11.GL_TRIANGLES, model.getRawModel().getVertextCount(), GL11.GL_UNSIGNED_INT, 0);

			}
			unbindTexturedModel();
		}
	}

	private void prepareTexturedModel(TexturedModel texturedModel) {
		GL30.glBindVertexArray(texturedModel.getRawModel().getVaoID());
		GL20.glEnableVertexAttribArray(0);
		GL20.glEnableVertexAttribArray(1);
		GL20.glEnableVertexAttribArray(2);

		GL13.glActiveTexture(GL13.GL_TEXTURE0);
		GL11.glBindTexture(GL11.GL_TEXTURE_2D, texturedModel.getTexture().getTextureID());
	}

	private void unbindTexturedModel() {
		GL20.glDisableVertexAttribArray(0);
		GL20.glDisableVertexAttribArray(1);
		GL20.glDisableVertexAttribArray(2);
		GL30.glBindVertexArray(0);
	}

	private void prepareInstance(GameObject go) {
		TransformComponent tc = (TransformComponent) go.findComponent(Component.TYPE_TRANSFORM_COMPONENT);
		Matrix4f tm = Utils.createTransformationMatrix(tc.getPosition(), tc.getRx(), tc.getRy(), tc.getRz(), tc.getScale());
		shader.loadTransformationMatrix(tm);
	}

	/**
	 * - renders a raw model 1. bind the model we want to use 2. enable the
	 * attribute list 3. RENDER 4. disables the list 5. Unbinds current VAO
	 * 
	 * @deprecated
	 */
	public void render(GameObject go, GameObjectShader shader) {
		RenderComponent rc = (RenderComponent) go.findComponent(Component.TYPE_RENDER_COMPONENT);
		TransformComponent tc = (TransformComponent) go.findComponent(Component.TYPE_TRANSFORM_COMPONENT);

		TexturedModel model = rc.getModel();
		GL30.glBindVertexArray(model.getRawModel().getVaoID());
		GL20.glEnableVertexAttribArray(0);
		GL20.glEnableVertexAttribArray(1);
		GL20.glEnableVertexAttribArray(2);

		// set uniforms
		Matrix4f tm = Utils.createTransformationMatrix(tc.getPosition(), tc.getRx(), tc.getRy(), tc.getRz(), tc.getScale());
		shader.loadTransformationMatrix(tm);

		GL13.glActiveTexture(GL13.GL_TEXTURE0);
		GL11.glBindTexture(GL11.GL_TEXTURE_2D, model.getTexture().getTextureID());

		GL11.glDrawElements(GL11.GL_TRIANGLES, model.getRawModel().getVertextCount(), GL11.GL_UNSIGNED_INT, 0);
		GL20.glDisableVertexAttribArray(0);
		GL20.glDisableVertexAttribArray(1);
		GL20.glDisableVertexAttribArray(2);
		GL30.glBindVertexArray(0);
	}
}
