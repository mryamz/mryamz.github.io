package renderers;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.lwjgl.opengl.GL11;

import components.Component;
import components.RenderComponent;
import gos.GameObject;
import lights.Light;
import models.TexturedModel;
import shaders.GameObjectShader;
import shaders.TerrainShader;
import terrains.Terrain;
import utils.ProjectionMatrix;

public class MasterRenderer {

	private GameObjectShader gameobject_shader = new GameObjectShader();
	private GameObjectRenderer gameObjectRenderer = new GameObjectRenderer(gameobject_shader);

	private TerrainShader terrain_shader = new TerrainShader();
	private TerrainRenderer terrainRenderer = new TerrainRenderer(terrain_shader);

	private Map<TexturedModel, List<GameObject>> gos = new HashMap<>();
	private List<Terrain> terrains = new ArrayList<>();

	public MasterRenderer() {
		ProjectionMatrix.getInstance().initProjectionMatrix();
		gameobject_shader.start();
		gameobject_shader.loadProjectionMatrix(ProjectionMatrix.getInstance().getProjectionMatrix());
		gameobject_shader.stop();

		terrain_shader.start();
		terrain_shader.loadProjectionMatrix(ProjectionMatrix.getInstance().getProjectionMatrix());
		terrain_shader.stop();
	}

	public void updateProjectionMatrix() {
		ProjectionMatrix.getInstance().updateProjectionMatrix();
		;
		gameobject_shader.start();
		gameobject_shader.loadProjectionMatrix(ProjectionMatrix.getInstance().getProjectionMatrix());
		gameobject_shader.stop();

		terrain_shader.start();
		terrain_shader.loadProjectionMatrix(ProjectionMatrix.getInstance().getProjectionMatrix());
		terrain_shader.stop();
	}

	public void render(Light light, Camera camera) {
		GL11.glDisable(GL11.GL_CULL_FACE);
		gameObjectRenderer.prepare();
		gameobject_shader.start();
		gameobject_shader.loadLight(light);
		gameobject_shader.loadViewMatrix(camera);
		gameObjectRenderer.render(gos);
		gameobject_shader.stop();

		GL11.glEnable(GL11.GL_CULL_FACE);
		GL11.glCullFace(GL11.GL_BACK);
		terrain_shader.start();
		terrain_shader.loadLight(light);
		terrain_shader.loadViewMatrix(camera);
		terrainRenderer.render(terrains);

		terrains.clear();
		gos.clear();
	}

	public void processTerrain(Terrain... terrain) {
		for (Terrain terrain2 : terrain) {
			terrains.add(terrain2);
		}
	}

	public void processGO(GameObject go) {
		RenderComponent rc = (RenderComponent) go.findComponent(Component.TYPE_RENDER_COMPONENT);
		TexturedModel model = rc.getModel();
		List<GameObject> batch = gos.get(go);
		if (batch != null) {
			batch.add(go);
		} else {
			List<GameObject> newBatch = new ArrayList<>();
			newBatch.add(go);
			gos.put(model, newBatch);
		}
	}

	public void cleanUp() {
		gameobject_shader.cleanUp();
		terrain_shader.cleanUp();
	}

}
