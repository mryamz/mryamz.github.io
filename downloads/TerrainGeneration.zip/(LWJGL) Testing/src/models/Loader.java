package models;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.nio.FloatBuffer;
import java.nio.IntBuffer;
import java.util.ArrayList;
import java.util.List;

import org.lwjgl.BufferUtils;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL14;
import org.lwjgl.opengl.GL15;
import org.lwjgl.opengl.GL20;
import org.lwjgl.opengl.GL30;
import org.newdawn.slick.opengl.Texture;
import org.newdawn.slick.opengl.TextureLoader;

/**
 * - Loads 3D models into memory - Stores positional data about the model as a
 * VAO
 */

public class Loader {

	private Loader() {
	}

	private static Loader loader;

	public static Loader getInstance() {
		if (loader == null) {
			loader = new Loader();
		}
		return loader;
	}

	// Track all created VAOs and VBOs
	private List<Integer> vaoIDs = new ArrayList<>();
	private List<Integer> vboIDs = new ArrayList<>();
	private List<Integer> textures = new ArrayList<>();

	/**
	 * - loads positional data into a VAO - returns information about VAO as a
	 * RawModel
	 */
	public RawModel loadToVAO(float[] positions, float[] textureCoords, float[] normals, int[] indices) {
		int vaoID = createVAO();
		bindIndicesBuffer(indices);
		storeInAttributeList(0, 3, positions);
		storeInAttributeList(1, 2, textureCoords);
		storeInAttributeList(2, 3, normals);
		unBindVAO();
		return new RawModel(vaoID, indices.length);
	}
	
	public RawModel loadToVao(float[] positions, int dimension) {
		int vaoID = createVAO();
		storeInAttributeList(0, dimension, positions);
		unBindVAO();
		return new RawModel(vaoID, positions.length / dimension);
	}

	/**
	 * - creates an empty VAO - returns the id of the newly found VAO
	 */
	private int createVAO() {
		int vaoID = GL30.glGenVertexArrays();
		vaoIDs.add(vaoID);
		GL30.glBindVertexArray(vaoID);
		return vaoID;
	}

	/**
	 * - loads a texture into OpenGL - returns the ID of that texture
	 */
	public int loadTexture(String fileName) {
		Texture texture = null;
		try {
			texture = TextureLoader.getTexture("PNG", new FileInputStream(fileName));

			GL30.glGenerateMipmap(GL11.GL_TEXTURE_2D);
			GL11.glTexParameteri(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_MIN_FILTER, GL11.GL_LINEAR_MIPMAP_NEAREST);
			GL11.glTexParameterf(GL11.GL_TEXTURE_2D, GL14.GL_TEXTURE_LOD_BIAS, -0.4f);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}

		int textureID = texture.getTextureID();
		textures.add(textureID);
		return textureID;
	}

	/**
	 * - stores data into the VAO's attribute list as a VBO
	 */

	private void storeInAttributeList(int number, int dimension, float[] data) {
		int vboID = GL15.glGenBuffers();
		vboIDs.add(vboID);
		GL15.glBindBuffer(GL15.GL_ARRAY_BUFFER, vboID);
		// stored VBO data has to be a float buffer
		FloatBuffer buffer = convertToBuffer(data);
		GL15.glBufferData(GL15.GL_ARRAY_BUFFER, buffer, GL15.GL_STATIC_DRAW);
		GL20.glVertexAttribPointer(number, dimension, GL11.GL_FLOAT, false, 0, 0);
		GL15.glBindBuffer(GL15.GL_ARRAY_BUFFER, 0);
	}

	/**
	 * - binds indices to a VAO
	 */
	private void bindIndicesBuffer(int[] indices) {
		int vboID = GL15.glGenBuffers();
		vboIDs.add(vboID);
		GL15.glBindBuffer(GL15.GL_ELEMENT_ARRAY_BUFFER, vboID);
		IntBuffer buffer = convertToBuffer(indices);
		GL15.glBufferData(GL15.GL_ELEMENT_ARRAY_BUFFER, buffer, GL15.GL_STATIC_DRAW);
	}

	/**
	 * Unbinds VAO
	 */
	private void unBindVAO() {
		GL30.glBindVertexArray(0);
	}

	/**
	 * - converts int[] to buffer
	 */
	private IntBuffer convertToBuffer(int[] data) {
		IntBuffer buffer = BufferUtils.createIntBuffer(data.length);
		buffer.put(data);
		buffer.flip();
		return buffer;
	}

	/**
	 * - stores data as float buffer - covert float[] to buffer
	 */
	private FloatBuffer convertToBuffer(float[] data) {
		FloatBuffer buffer = BufferUtils.createFloatBuffer(data.length);
		buffer.put(data);
		buffer.flip();
		return buffer;
	}

	/**
	 * - manually removes all created VAOs and VBOs from memory.
	 */
	public void cleanUp() {
		for (int integer : vaoIDs) {
			GL30.glDeleteVertexArrays(integer);
		}

		for (int integer : vboIDs) {
			GL15.glDeleteBuffers(integer);
		}

		for (int integer : textures) {
			GL15.glDeleteBuffers(integer);
		}
	}
}
