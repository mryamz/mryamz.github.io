package models;

/**
 * Holds important data about our model.
 * This represents our model's VAO and the Vertex count
 * 
 * @author admin
 *
 */

public class RawModel {

	private int vaoID;
	private int vertextCount;

	public RawModel(int vaoID, int vertextCount) {
		this.vaoID = vaoID;
		this.vertextCount = vertextCount;
	}

	public int getVaoID() {
		return vaoID;
	}

	public int getVertextCount() {
		return vertextCount;
	}

}
