package models;

/**
 * - represents the texture used for the model
 *
 */

public class ModelTexture {

	private int textureID;

	public ModelTexture(int textureID) {
		this.textureID = textureID;
	}

	public int getTextureID() {
		return textureID;
	}
}
