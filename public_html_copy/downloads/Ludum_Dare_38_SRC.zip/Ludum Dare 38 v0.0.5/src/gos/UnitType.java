package gos;

public enum UnitType {

	BASIC_UNIT("Basic Cell", 150, 300, 100, 100),
	ADVANCED_UNIT("Advanced Cell", 300, 100 * 3, 200, 200);

	private String name;

	private int xp;
	private int level;

	private float attackRadius;
	private float speed;
	private float health;
	
	public final float MAX_HEALTH;
	
	private UnitType(String name, float attackRadius, float speed, float health, final float MAX_HEALTH) {
		this.MAX_HEALTH = MAX_HEALTH;
		this.name = name;
		this.attackRadius = attackRadius;
		this.speed = speed;
		this.health = health;
	}

	public String getName() {
		return name;
	}

	public int getXp() {
		return xp;
	}

	public int getLevel() {
		return level;
	}

	public float getAttackRadius() {
		return attackRadius;
	}

	public float getSpeed() {
		return speed;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void setAttackRadius(float attackRadius) {
		this.attackRadius = attackRadius;
	}

	public void setSpeed(float speed) {
		this.speed = speed;
	}

	public void setHealth(float health) {
		this.health = health;
	}

	public void setXp(int xp) {
		this.xp = xp;
	}

	public void setLevel(int level) {
		this.level = level;
	}

	public float getHealth() {
		return health;
	}

}