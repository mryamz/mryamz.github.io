package gos;

import java.awt.image.BufferedImage;

public interface Controllable {
	
	void moveTo(int x, int y);
	
	void attack(Entity e);

	void setImage(BufferedImage img);
}
