package gos;

import java.awt.Graphics2D;

public abstract class Entity implements Controllable {

	protected UnitType type;
	protected float x, y;
	protected float tx = -1, ty = -1;

	protected boolean isActive;
	protected boolean isTargetPicked;
	protected boolean isDoneMoving;
	protected boolean hasAttacked;

	protected float health;
	protected final float MAX_HEALTH;

	public Entity(UnitType type, float x, float y) {
		this.type = type;
		this.x = x;
		this.y = y;
		health = type.getHealth();
		MAX_HEALTH = type.MAX_HEALTH;
	}
	
	public void modifyHealth(int amt) {
		health += amt;
	}

	public abstract void update();

	public abstract void draw(Graphics2D g2);
	
	public abstract float getRadius();

	public abstract void mouseMoved(int x, int y);
	
	public UnitType getType() {
		return type;
	}

	public void onNextTurn() {
		isTargetPicked = false;
		isDoneMoving = false;
		isActive = false;
		hasAttacked = false;
	}
	
	public float getX() {
		return x;
	}
	
	public float getHealth() {
		return health;
	}

	public float getY() {
		return y;
	}
	
	public boolean isDoneMoving() {
		return isDoneMoving;
	}
	
	public boolean isHasAttacked() {
		return hasAttacked;
	}
}
