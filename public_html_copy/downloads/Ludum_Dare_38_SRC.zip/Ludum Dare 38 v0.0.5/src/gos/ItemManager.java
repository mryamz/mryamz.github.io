package gos;

import java.awt.Graphics2D;
import java.util.List;
import java.util.Random;
import java.util.concurrent.CopyOnWriteArrayList;

import audio.AudioPlayer;
import main.AppPanel;
import ui.NotificationManager;

public class ItemManager {

	private List<Item> items = new CopyOnWriteArrayList<>();
	
	public int whitesItemCount;

	public void checkcollisions(List<Entity> cancer, List<Entity> white) {
		for (Entity entity : cancer) {
			for (Item item : items) {
				float dx = item.getX() - entity.x;
				float dy = item.getY() - entity.y;

				float dist = (float) Math.sqrt(dx * dx + dy * dy);
				if (dist < item.getR() + entity.getRadius()) {
					item.onCollect(entity, cancer, true);
					items.remove(item);
				}
			}
		}

		for (Entity entity : white) {
			for (Item item : items) {
				float dx = item.getX() - entity.x;
				float dy = item.getY() - entity.y;

				float dist = (float) Math.sqrt(dx * dx + dy * dy);
				if (dist < item.getR() + entity.getRadius()) {
					item.onCollect(entity, white, false);
					whitesItemCount++;
					items.remove(item);
					AudioPlayer.sfx.get("item_collected").play();
				}
			}
		}
	}

	public void addItem() {
		items.add(new Item(new Random().nextInt(AppPanel.WIDTH - 60), new Random().nextInt(AppPanel.HEIGHT - 60), new Random().nextInt(3)));
		NotificationManager.getInstance().queueNotif("A new item has spawned.");
		AudioPlayer.sfx.get("item_spawn").play();
	}

	public void draw(Graphics2D g2) {
		for (Item item : items) {
			item.draw(g2);
		}
	}
}
