package gos;

import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.util.List;

import ui.Images;
import ui.NotificationManager;

public class Item {

	public static final int ITEM_TYPE_x2 = 0;
	public static final int FULL_HEAL = 1;
	public static final int PROMOTION = 2;

	private int x, y;
	private int type;
	private float r;
	private BufferedImage img;

	public Item(int x, int y, int type) {
		this.x = x;
		this.y = y;
		this.type = type;
		switch (type) {
		case FULL_HEAL:
			img = Images.HEAL_ITEM;
			break;

		case ITEM_TYPE_x2:
				img = Images.x2_ITEM;
			break;

		case PROMOTION:
				img = Images.PROMO_ITEM;
			break;
		}

		r = img.getWidth() / 2;
	}

	public void draw(Graphics2D g2) {
		g2.drawImage(img, x, y, null);
	}

	public void onCollect(Entity e, List<Entity> entities, boolean isCancer) {
		if (type == FULL_HEAL) {
			e.health += e.MAX_HEALTH - e.health + 1;
			NotificationManager.getInstance().queueNotif(isCancer ? "A cancer cell collected a full heal." : "Your cell collected a full heal.");
		}

		if (type == PROMOTION) {
			e.type = UnitType.ADVANCED_UNIT;
			e.health += e.type.MAX_HEALTH - e.health + 1;
			if (!isCancer)
				e.setImage(Images.ADVANCED_WHITE_BLOOD_CELL);
			else
				e.setImage(Images.ADCANCED_BLACK_BLOOD_CELL);
			NotificationManager.getInstance().queueNotif(isCancer ? "A cancer cell got a promotion." : "Your cell got a promotion.");
		}

		if (type == ITEM_TYPE_x2) {
			FlexiUnit fu1 = new FlexiUnit(e.x + e.getRadius(), e.y, UnitType.BASIC_UNIT);
			if (!isCancer)
				fu1.setImage(Images.WHITE_BLOOD_CELL);
			else
				fu1.setImage(Images.BLACK_BLOOD_CELL);
			entities.add(fu1);

			FlexiUnit fu2 = new FlexiUnit(e.x - e.getRadius(), e.y, UnitType.BASIC_UNIT);
			if (!isCancer)
				fu2.setImage(Images.WHITE_BLOOD_CELL);
			else
				fu2.setImage(Images.BLACK_BLOOD_CELL);
			entities.add(fu2);

			NotificationManager.getInstance().queueNotif(isCancer ? "A cancer cell has split." : "Your cell divided.");

		}
	}

	public int getX() {
		return x;
	}

	public void setX(int x) {
		this.x = x;
	}

	public int getY() {
		return y;
	}

	public void setY(int y) {
		this.y = y;
	}

	public int getType() {
		return type;
	}

	public void setType(int type) {
		this.type = type;
	}

	public float getR() {
		return r;
	}

	public void setR(float r) {
		this.r = r;
	}

	public BufferedImage getImg() {
		return img;
	}

	public void setImg(BufferedImage img) {
		this.img = img;
	}
}
