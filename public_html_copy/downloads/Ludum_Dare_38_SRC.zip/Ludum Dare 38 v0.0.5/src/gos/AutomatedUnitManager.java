package gos;

import java.awt.Graphics2D;
import java.io.IOException;
import java.util.List;
import java.util.Random;
import java.util.concurrent.CopyOnWriteArrayList;

import javax.imageio.ImageIO;

import audio.AudioPlayer;
import states.PlayState;
import ui.NotificationManager;

public class AutomatedUnitManager {

	private List<Entity> entities = new CopyOnWriteArrayList<>();

	private int activeCellIndex;

	private ManualUnitManager mum;

	private int targetCellIndex;
	
	public int cellsCapt;

	public AutomatedUnitManager() {

		for (int i = 0; i < 4; i++) {
			entities.add(new FlexiUnit(250 + i * 60, 150, UnitType.BASIC_UNIT));
		}
		for (int i = 0; i < entities.size(); i++) {
			try {
				entities.get(i).setImage(ImageIO.read(Class.class.getResourceAsStream("/entities/blackbloodcell.png")));
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}

	public void onNewTurn() {
		for (Entity entity : entities) {
			entity.onNextTurn();
		}
	}

	public void update() {
		if (PlayState.isAIsTurn) {
			entities.get(activeCellIndex).isActive = true;
			int[] coords = getTargetCoords();
			entities.get(activeCellIndex).moveTo(coords[0], coords[1]);
			entities.get(activeCellIndex).update();

			if (entities.get(activeCellIndex).isDoneMoving) {
				activeCellIndex++;
				if (activeCellIndex > entities.size() - 1) {
					activeCellIndex = 0;
					onNewTurn();
					PlayState.isAIsTurn = false;
					return;
				}
			}
		}
	}

	private int[] getTargetCoords() {
		int[] xy = new int[2];
		Entity acell = entities.get(activeCellIndex);
		Entity trgt = mum.getEntities().get(targetCellIndex);

		float dx = trgt.x - acell.x;
		float dy = trgt.y - acell.y;

		double dist = Math.sqrt(dx * dx + dy * dy);

		if (dist < acell.type.getAttackRadius() / 2 + trgt.getRadius()) {
			xy[0] = (int) (acell.x);
			xy[1] = (int) (acell.y);

			if (!acell.hasAttacked) {
				trgt.modifyHealth(-20);
				AudioPlayer.sfx.get("white_hurt").play();
				acell.hasAttacked = true;
			}
			if (trgt.getHealth() < 0) {
				FlexiUnit nu = (new FlexiUnit(trgt.x, trgt.y, UnitType.BASIC_UNIT));
				try {
					nu.setImage(ImageIO.read(Class.class.getResourceAsStream("/entities/blackbloodcell.png")));
				} catch (IOException e) {
					e.printStackTrace();
				}
				cellsCapt++;
				entities.add(nu);
				AudioPlayer.sfx.get("cell_explodes").play();
				NotificationManager.getInstance().queueNotif("A cancer cell captured your cell!");
				mum.getEntities().remove(trgt);
				targetCellIndex = new Random().nextInt(mum.getEntities().size() == 0 ? 1 : mum.getEntities().size());
			}
			return xy;
		}

		if (dx == 0)
			dx += 5;

		if (dy == 0)
			dy += 5;

		dx /= dist;
		dy /= dist;

		dx *= acell.type.getSpeed() / 2;
		dy *= acell.type.getSpeed() / 2;

		xy[0] = (int) (dx + acell.x + new Random().nextInt(60) - 30);
		xy[1] = (int) (dy + acell.y + new Random().nextInt(60) - 30);

		return xy;
	}

	public void draw(Graphics2D g2) {
		for (Entity entity : entities) {
			entity.draw(g2);
		}
	}

	public List<Entity> getEntities() {
		return entities;
	}

	public void setMum(ManualUnitManager mum) {
		this.mum = mum;
		targetCellIndex = new Random().nextInt(mum.getEntities().size());

	}
	// done ever 3 turns
	public void splitCancerCells() {
		for (Entity entity : entities) {
			boolean isAdvanced = new Random().nextInt(6) == 0;
			FlexiUnit nu = new FlexiUnit(entity.x + entity.getRadius(), entity.y, isAdvanced ? UnitType.ADVANCED_UNIT : UnitType.BASIC_UNIT);
			try {
				nu.setImage(isAdvanced ? ImageIO.read(Class.class.getResourceAsStream("/entities/adv_blackbloodcell.png")) : ImageIO.read(Class.class.getResourceAsStream("/entities/blackbloodcell.png")));
			} catch (IOException e) {
				e.printStackTrace();
			}
			entities.add(nu);
		}
		
		AudioPlayer.sfx.get("cancer_splits").play();
		NotificationManager.getInstance().queueNotif("All cancer cells have split.");
	}

}
