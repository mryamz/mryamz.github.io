package gos;

import java.awt.Graphics2D;
import java.awt.event.MouseEvent;
import java.io.IOException;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.ThreadLocalRandom;

import javax.imageio.ImageIO;

import audio.AudioPlayer;
import main.AppPanel;
import states.PlayState;

public class ManualUnitManager {

	public int numCellsCapt;

	public void setAum(AutomatedUnitManager aum) {
		this.aum = aum;
	}

	private List<Entity> entities = new CopyOnWriteArrayList<>();

	private AutomatedUnitManager aum;

	public ManualUnitManager() {
		for (int i = 0; i < 4; i++) {
			entities.add(new FlexiUnit(250 + i * 60, AppPanel.HEIGHT - 150, UnitType.BASIC_UNIT));
			try {
				entities.get(i).setImage(ImageIO.read(Class.class.getResourceAsStream("/entities/whilebloodcell.png")));
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}

	public void mouseReleased(MouseEvent e) {
		if (e.getButton() == MouseEvent.BUTTON1) {

			for (Entity entity : entities) {
				float x1 = entity.x + entity.getRadius();
				float y1 = entity.y + entity.getRadius();

				float dist = (float) Math.sqrt((((x1 - e.getX()) * (x1 - e.getX())) + ((y1 - e.getY()) * (y1 - e.getY()))));
				if (dist < entity.getRadius()) {
					try {
						getActiveUnit().isActive = false;
					} catch (Exception e1) {
					}
					entity.isActive = true;
					entity.tx = e.getX();
					entity.ty = e.getY();
				}

				if (dist > entity.getRadius() && dist < entity.getType().getSpeed() / 2) {
					if (entity.isActive) {
						if (!entity.isDoneMoving)
							AudioPlayer.sfx.get("cell_moved").play();
						entity.moveTo((int) (e.getX() - entity.getRadius()), (int) (e.getY() - entity.getRadius()));
					}
				}
			}
		} else if (e.getButton() == MouseEvent.BUTTON3) {
			try {
				Entity au = getActiveUnit();
				for (Entity enemyEntity : aum.getEntities()) {

					float dx = (au.x + au.getRadius()) - (enemyEntity.x + enemyEntity.getRadius());
					float dy = (au.y + au.getRadius()) - (enemyEntity.y + enemyEntity.getRadius());

					double distFromEnemy = Math.sqrt(dx * dx + dy * dy);

					if (distFromEnemy < (au.type.getAttackRadius() / 2) + enemyEntity.getRadius()) {
						float mx = e.getX() - (enemyEntity.x + enemyEntity.getRadius());
						float my = e.getY() - (enemyEntity.y + enemyEntity.getRadius());
						double distFromMouse = Math.sqrt(mx * mx + my * my);

						if (distFromMouse < enemyEntity.getRadius()) {
							int healthLoss = ThreadLocalRandom.current().nextInt(10, 30);
							if (!au.hasAttacked) {
								if (au.type == UnitType.ADVANCED_UNIT)
									healthLoss *= 3;
								enemyEntity.modifyHealth(-healthLoss);
								au.hasAttacked = true;
								System.out.println("Enemy lost: " + healthLoss);
							}

							if (enemyEntity.getHealth() < 0) {
								FlexiUnit nu = new FlexiUnit(enemyEntity.getX(), enemyEntity.getY(), UnitType.BASIC_UNIT);
								try {
									nu.setImage(ImageIO.read(Class.class.getResourceAsStream("/entities/whilebloodcell.png")));
								} catch (IOException e1) {
									e1.printStackTrace();
								}
								aum.getEntities().remove(enemyEntity);
								entities.add(nu);
								numCellsCapt++;
							}
						}
					}
				}
			} catch (NullPointerException e1) {
				e1.printStackTrace();
			}
		}
	}

	public void mouseMoved(MouseEvent e) {
		try {
			Entity au = getActiveUnit();
			au.mouseMoved(e.getX(), e.getY());

		} catch (Exception e1) {
		}
	}

	public Entity getActiveUnit() throws NullPointerException {
		for (Entity entity : entities) {
			if (entity.isActive)
				return entity;
		}

		return null;
	}

	public void onNewTurn() {
		for (Entity entity : entities) {
			entity.onNextTurn();
		}
	}

	public void update() {
		if (!PlayState.isAIsTurn)
			for (Entity entity : entities) {
				entity.update();
			}
	}

	public void draw(Graphics2D g2) {
		for (Entity entity : entities) {
			entity.draw(g2);
		}
	}

	public void deselect() {
		getActiveUnit().isActive = false;
	}

	public List<Entity> getEntities() {
		return entities;
	}

}
