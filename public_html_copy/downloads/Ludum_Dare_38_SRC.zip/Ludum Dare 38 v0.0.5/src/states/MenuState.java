package states;

import java.awt.AlphaComposite;
import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Composite;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.event.KeyEvent;
import java.awt.event.MouseEvent;
import java.awt.geom.Rectangle2D;
import java.awt.image.BufferedImage;
import java.io.IOException;

import javax.imageio.ImageIO;

import main.AppPanel;
import ui.Button;
import ui.OnClickListener;
import ui.UIElementManager;

public class MenuState implements AppState {

	private UIElementManager uiem;

	private String title = "Under the Petri Dish";
	private String sub_title = "a small world...";

	private Font title_font = new Font("System", Font.PLAIN, 65);
	private Font sub_font = new Font("System", Font.PLAIN, 26);

	private BufferedImage bg_blur;
	private BufferedImage bg_sharp;

	private Rectangle bg_sharp_bounds;

	private long timer;
	private boolean transStarted;

	private int xoff;

	private boolean dark_bg_hasCleared;
	private boolean expandSharp;

	public MenuState() {

		int w = 150;
		int h = 65;

		int x = AppPanel.WIDTH / 2 - w / 2;
		int y = (int) (AppPanel.HEIGHT / 2.5);
		Button b = new Button(x, y, w, h).setBg_color(Color.ORANGE).setText("Play");
		b.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick() {
				beginTransition();
			}
		});

		uiem = new UIElementManager();
		uiem.add(b);

		try {
			bg_blur = ImageIO.read(Class.class.getResourceAsStream("/bgs/bg_01_blur.png"));
			bg_sharp = ImageIO.read(Class.class.getResourceAsStream("/bgs/bg_01.png"));
		} catch (IOException e) {
			e.printStackTrace();
		}

		bg_sharp_bounds = new Rectangle(0, 0, bg_sharp.getWidth(), bg_sharp.getHeight());
	}

	@Override
	public void update() {
		uiem.update();
	}

	@Override
	public void draw(Graphics2D g2) {
		g2.clearRect(0, 0, AppPanel.WIDTH, AppPanel.HEIGHT);

		long e1 = (System.nanoTime() - timer) / 1_000_000;

		float alpha = 1f;
		if (transStarted && !expandSharp) {
			alpha = 1f - (float) Math.sin(e1 * Math.PI / 8_000);
			if (e1 > 4000) {
				expandSharp = true;
			}
		}

		if (expandSharp) {
			int yExpaseSpeed = -2;
			int hExpaseSpeed = 2;
			int xExpaseSpeed = -1;
			int wExpaseSpeed = 2;
			if (bg_sharp_bounds.y < -580) {
				yExpaseSpeed = -10;
				hExpaseSpeed = 12;
				xExpaseSpeed = -4;
				wExpaseSpeed = 8;

				if (bg_sharp_bounds.y < -3000) {
					yExpaseSpeed = -5;
					hExpaseSpeed = 12;
					xExpaseSpeed = -8;
					wExpaseSpeed = 16;

					if (bg_sharp_bounds.y < -3305) {
						AppStateManager.setAppState(new PlayState());
					}
				}
			}
			bg_sharp_bounds.setBounds(bg_sharp_bounds.x + xExpaseSpeed, bg_sharp_bounds.y + yExpaseSpeed, bg_sharp_bounds.width + wExpaseSpeed, bg_sharp_bounds.height + hExpaseSpeed);
			System.out.println(bg_sharp_bounds);
		}

		Composite old = g2.getComposite();
		if (!expandSharp) {
			g2.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, alpha));
			g2.drawImage(bg_blur, 0, 0, null);
		}

		if (!expandSharp)
			g2.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 1f - alpha));

		g2.drawImage(bg_sharp, bg_sharp_bounds.x, bg_sharp_bounds.y, bg_sharp_bounds.width, bg_sharp_bounds.height, null);

		int a1 = 200;
		if (transStarted && !dark_bg_hasCleared) {
			a1 = 200 - (int) ((175 * Math.sin(e1 * Math.PI / 5000)));
			a1 = Math.min(a1, 200);
			if (a1 <= 30) {
				dark_bg_hasCleared = true;
			}
		}

		g2.setComposite(old);
		g2.setColor(new Color(0, 0, 0, dark_bg_hasCleared ? 30 : a1));
		if (!expandSharp)
			g2.fillRect(0, 0, AppPanel.WIDTH, AppPanel.HEIGHT);
		uiem.draw(g2);

		// bg text
		if (transStarted) {
			xoff += 15;
		}
		g2.setStroke(new BasicStroke(4));
		g2.setColor(new Color(0, 0, 0, 175));
		g2.fillRect(165 + xoff, 0, 800 - 165, 125);
		g2.setColor(Color.ORANGE);
		g2.drawRect(165 + xoff, 2, 800 - 165 - 2, 125);
		g2.setStroke(new BasicStroke(1));

		int right_margin = 30;
		g2.setColor(Color.ORANGE);
		g2.setFont(title_font);
		Rectangle2D titleBounds = g2.getFontMetrics(title_font).getStringBounds(title, g2);
		g2.drawString(title, AppPanel.WIDTH - (int) titleBounds.getWidth() - right_margin + xoff, (int) titleBounds.getHeight());

		g2.setFont(sub_font);
		Rectangle2D subtitleBounds = g2.getFontMetrics(sub_font).getStringBounds(sub_title, g2);
		g2.drawString(sub_title, AppPanel.WIDTH - (int) subtitleBounds.getWidth() - right_margin + xoff, (int) subtitleBounds.getHeight() + (int) titleBounds.getHeight());

		if (transStarted)
			g2.drawString("(Space to Skip)", AppPanel.WIDTH / 2 - g2.getFontMetrics().stringWidth("(Space to Skip)") / 2, AppPanel.HEIGHT - 30);

	}

	@Override
	public void keyPressed(int keycode) {
	}

	@Override
	public void keyReleased(int keycode) {
		if(keycode == KeyEvent.VK_SPACE) {
			AppStateManager.setAppState(new PlayState());
		}
	}

	@Override
	public void mouseMoved(MouseEvent e) {
		uiem.mouseMoved(e);
	}

	@Override
	public void mousePressed(MouseEvent e) {
		uiem.mousePressed(e);
	}

	@Override
	public void mouseReleased(MouseEvent e) {
		uiem.mouseReleased(e);
	}

	private void beginTransition() {
		uiem.clear();

		transStarted = true;
		timer = System.nanoTime();
	}
}
