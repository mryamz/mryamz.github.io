package states;

import java.awt.Graphics2D;
import java.awt.event.MouseEvent;

public interface AppState {

	void update();
	
	void draw(Graphics2D g2);
	
	void keyPressed(int keycode);
	
	void keyReleased(int keycode);
	
	void mouseMoved(MouseEvent e);
	
	void mousePressed(MouseEvent e);
	
	void mouseReleased(MouseEvent e);
	
}
