package states;

public class AppStateManager {

	private static AppState appState;
	
	public static AppState getAppState() {
		return appState;
	}

	public static void setAppState(AppState appState) {
		AppStateManager.appState = appState;
	}


}
