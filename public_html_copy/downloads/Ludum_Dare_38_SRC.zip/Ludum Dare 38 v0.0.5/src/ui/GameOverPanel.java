package ui;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.event.MouseEvent;

import main.AppPanel;
import states.AppStateManager;
import states.MenuState;
import states.PlayState;

public class GameOverPanel implements UIElement {

	private Rectangle bounds;
	private boolean isVisible = false;

	private String winStatus = "Null";
	private String cellsCapt = "Null";
	private String cellsLost = "Null";
	private String itemsCollected = "Null";
	
	private Button retry, menu;

	public GameOverPanel() {
		int width = AppPanel.WIDTH / 2;
		int height = 500;
		bounds = new Rectangle(AppPanel.WIDTH / 2 - width / 2, 60, width, height);
		
		retry = new Button(bounds.x + 20, bounds.y + bounds.height - 70, 125, 50).setBg_color(Color.GREEN).setText("Retry").setFont(new Font("System", Font.BOLD, 25)).setFnt_color(Color.BLACK);
		menu = new Button(bounds.x + bounds.width - 20 - 125, bounds.y + bounds.height - 70, 125, 50).setBg_color(Color.RED).setText("Quit").setFont(new Font("System", Font.BOLD, 25)).setFnt_color(Color.BLACK);
		
		retry.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick() {
				AppStateManager.setAppState(new PlayState());
			}
		});
		
		menu.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick() {
				AppStateManager.setAppState(new MenuState());
			}
		});
	}

	@Override
	public void update() {
		if (!isVisible)
			return;
		retry.update();
		menu.update();
	}

	@Override
	public void draw(Graphics2D g2) {

		if (isVisible) {
			Font f = g2.getFont();
			g2.setColor(new Color(0, 0, 0, 230));
			g2.fillRoundRect(bounds.x, bounds.y, bounds.width, bounds.height, 70, 70);
			g2.setStroke(new BasicStroke(5));
			g2.setColor(Color.WHITE);
			g2.drawRoundRect(bounds.x, bounds.y, bounds.width, bounds.height, 70, 70);
			g2.setFont(new Font("System", Font.PLAIN, 50));
			g2.drawString("Game Over", bounds.x + bounds.width / 2 - 130, bounds.y + 65);
			g2.setFont(new Font("System", Font.PLAIN, 36));
			g2.drawString(winStatus, bounds.x + bounds.width / 2 - 150, bounds.y + 150);
			g2.drawString(cellsCapt, bounds.x + bounds.width / 2 - 150, bounds.y + 200);
			g2.drawString(cellsLost, bounds.x + bounds.width / 2 - 150, bounds.y + 250);
			g2.drawString(itemsCollected, bounds.x + bounds.width / 2 - 150, bounds.y + 300);

			g2.setFont(f);
			
			retry.draw(g2);
			menu.draw(g2);
		}
	}

	public void show(boolean won, int cellsCapt, int cellsLost, int itemsCollected) {
		isVisible = true;
		winStatus = won ? "You won winner!" : "You lost loser.";
		this.cellsCapt = "You captured " + cellsCapt + " cells.";
		this.cellsLost = cellsLost + " cell(s) were lost.";
		this.itemsCollected = itemsCollected + " items collected.";
	}

	@Override
	public Rectangle getBounds() {
		return bounds;
	}

	@Override
	public void mousePressed(MouseEvent e) {
		if (!isVisible)
			return;
		retry.mousePressed(e);
		menu.mousePressed(e);
	}

	@Override
	public void mouseReleased(MouseEvent e) {
		if (!isVisible)
			return;
		retry.mouseReleased(e);
		menu.mouseReleased(e);
	}

	@Override
	public void mouseMoved(MouseEvent e) {
		if (!isVisible)
			return;
		retry.mouseMoved(e);
		menu.mouseMoved(e);
	}

	public void setVisible(boolean isVisible) {
		this.isVisible = isVisible;
	}
}
