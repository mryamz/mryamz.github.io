package ui;

public interface OnClickListener {

	void onClick();
	
}
