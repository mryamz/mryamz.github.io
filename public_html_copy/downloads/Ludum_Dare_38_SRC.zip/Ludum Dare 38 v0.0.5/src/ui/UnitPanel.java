package ui;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.event.MouseEvent;

import gos.ManualUnitManager;
import main.AppPanel;
import states.PlayState;

public class UnitPanel implements UIElement {

	private Rectangle bounds;

	private Font head = new Font("System", Font.PLAIN, 23);
	private Font sub = new Font("System", Font.PLAIN, 16);

	private ManualUnitManager mum;

	public UnitPanel(ManualUnitManager mum) {
		this.mum = mum;
		int w = 220;
		int x = 0;
		int h = 250;
		int y = AppPanel.HEIGHT - h;
		bounds = new Rectangle(x, y, w, h);
	}

	@Override
	public void update() {

	}

	@Override
	public void draw(Graphics2D g2) {
		g2.setColor(new Color(0, 0, 0, 150));
		g2.fillRoundRect(bounds.x, bounds.y, bounds.width, bounds.height, 30, 30);
		g2.setColor(Color.WHITE);
		g2.setStroke(new BasicStroke(4f));
		g2.drawRoundRect(bounds.x + 2, bounds.y-2, bounds.width, bounds.height, 30, 30);
		g2.setStroke(new BasicStroke(1));

		g2.setFont(head);
		String text = mum.getActiveUnit() == null ? PlayState.isAIsTurn ? "Waiting for ai..." : "Select White Cell" : mum.getActiveUnit().getType().getName();
		g2.drawString(text, 200 / 2 - g2.getFontMetrics().stringWidth(text) / 2, AppPanel.HEIGHT - 210);
	
		g2.setFont(sub);
		String movedStatus = mum.getActiveUnit() == null ? "Left Click: Moves a cell" : "- Moved: " + mum.getActiveUnit().isDoneMoving();
		g2.drawString(movedStatus, 10, AppPanel.HEIGHT - 175);

		String attackStatus = mum.getActiveUnit() == null ? "Right Click: Attacks a cell" : "- Attacked: " + mum.getActiveUnit().isHasAttacked();
		g2.drawString(attackStatus, 10, AppPanel.HEIGHT - 150);
		
		String healthStatus = mum.getActiveUnit() == null ? "Hover: Views a cell's health." : "- Health: " + String.format("%s%%", (mum.getActiveUnit().getHealth() / mum.getActiveUnit().getType().MAX_HEALTH) * 100);
		g2.drawString(healthStatus, 10, AppPanel.HEIGHT - 125);
		
		if(mum.getActiveUnit() == null) {
			g2.drawString("Space: Deselect cell", 10, AppPanel.HEIGHT - 100);
		}
	}

	@Override
	public Rectangle getBounds() {
		return bounds;
	}

	@Override
	public void mousePressed(MouseEvent e) {

	}

	@Override
	public void mouseReleased(MouseEvent e) {

	}

	@Override
	public void mouseMoved(MouseEvent e) {

	}

}
