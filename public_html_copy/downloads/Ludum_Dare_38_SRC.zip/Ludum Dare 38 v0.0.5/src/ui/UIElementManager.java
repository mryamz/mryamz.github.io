package ui;

import java.awt.Graphics2D;
import java.awt.event.MouseEvent;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

public class UIElementManager {

	private List<UIElement> elements = new CopyOnWriteArrayList<>();

	public void update() {
		for (UIElement uiElement : elements) {
			uiElement.update();
		}
	}

	public void draw(Graphics2D g2) {
		for (UIElement uiElement : elements) {
			uiElement.draw(g2);
		}
	}

	public void mouseMoved(MouseEvent e) {
		for (UIElement uiElement : elements) {
			uiElement.mouseMoved(e);
		}
	}

	public void mousePressed(MouseEvent e) {
		for (UIElement uiElement : elements) {
			uiElement.mousePressed(e);
		}
	}

	public void mouseReleased(MouseEvent e) {
		for (UIElement uiElement : elements) {
			uiElement.mouseReleased(e);
		}
	}

	public void add(UIElement... elements) {
		for (int i = 0; i < elements.length; i++) {
			this.elements.add(elements[i]);
		}
	}
	
	public void clear() {
		elements.clear();
	}
}
