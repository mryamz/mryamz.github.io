package ui;

import java.awt.image.BufferedImage;
import java.io.IOException;

import javax.imageio.ImageIO;

public class Images {

	public static BufferedImage ADVANCED_WHITE_BLOOD_CELL;
	public static BufferedImage ADCANCED_BLACK_BLOOD_CELL;
	
	public static BufferedImage WHITE_BLOOD_CELL;
	public static BufferedImage BLACK_BLOOD_CELL;

	public static BufferedImage HEAL_ITEM;
	public static BufferedImage x2_ITEM;
	public static BufferedImage PROMO_ITEM;
	static {
		try {
			ADVANCED_WHITE_BLOOD_CELL = ImageIO.read(Class.class.getResourceAsStream("/entities/adv_whilebloodcell.png"));
			ADCANCED_BLACK_BLOOD_CELL = ImageIO.read(Class.class.getResourceAsStream("/entities/adv_blackbloodcell.png"));
			HEAL_ITEM = ImageIO.read(Class.class.getResourceAsStream("/entities/heal-item.png"));
			x2_ITEM = ImageIO.read(Class.class.getResourceAsStream("/entities/x2-item.png"));
			PROMO_ITEM = ImageIO.read(Class.class.getResourceAsStream("/entities/promo-item.png"));
			WHITE_BLOOD_CELL = ImageIO.read(Class.class.getResourceAsStream("/entities/whilebloodcell.png"));
			BLACK_BLOOD_CELL = ImageIO.read(Class.class.getResourceAsStream("/entities/blackbloodcell.png"));
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

}
