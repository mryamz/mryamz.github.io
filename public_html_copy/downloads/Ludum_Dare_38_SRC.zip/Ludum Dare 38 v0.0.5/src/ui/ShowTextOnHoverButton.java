package ui;

import java.awt.Graphics2D;

public class ShowTextOnHoverButton extends Button {

	private TextPanel text;

	public ShowTextOnHoverButton(int x, int y, int w, int h) {
		super(x, y, w, h);
	}

	@Override
	public void draw(Graphics2D g2) {
		super.draw(g2);
		
		if(isHovering()) {
			text.draw(g2);
		}
	}

	public Button setTextPanel(TextPanel tp) {
		this.text = tp;
		return this;
	}
}
