package ui;

import java.awt.event.MouseEvent;

import audio.AudioPlayer;

public abstract class Pushable implements UIElement {
	
	private boolean isHovering;

	OnClickListener onClickListener = new OnClickListener() {
		@Override
		public void onClick() {
			System.out.println("Not initialized. Must set on click listener.");
		}
	};
	
	public void setOnClickListener(OnClickListener onClickListener) {
		this.onClickListener = onClickListener;
	}
	
	@Override
	public void mouseMoved(MouseEvent e) {
		isHovering = (getBounds().contains(e.getPoint()));
	}
	
	@Override
	public void mouseReleased(MouseEvent e) {
		if(getBounds().contains(e.getPoint())) {
			AudioPlayer.sfx.get("button_clicked").play();
			onClickListener.onClick();
		}
	}
	
	public boolean isHovering() {
		return isHovering;
	}
}
